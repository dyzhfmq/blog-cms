"""Prepare a public-content-only, independent static preview; never read admin data."""
import json, re, shutil, urllib.request
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dest = root / 'share-preview' / 'ittext-editorial'
dest.mkdir(parents=True, exist_ok=True)
def get(path):
    with urllib.request.urlopen('http://127.0.0.1:8080' + path, timeout=20) as response:
        return json.load(response)

for name in ['src', 'public']:
    shutil.copytree(root / 'web' / name, dest / name, dirs_exist_ok=True)
for name in ['index.html', 'package.json', 'package-lock.json']:
    shutil.copy2(root / 'web' / name, dest / name)
articles = []
for kind in ['ARTICLE', 'PAGE']:
    page = 1
    while True:
        result = get(f'/api/articles?kind={kind}&size=100&page={page}')
        articles.extend(get('/api/articles/' + str(a['id'])) for a in result['items'])
        if page * 100 >= result['total']: break
        page += 1
assert articles and all(a['status'] == 'PUBLISHED' for a in articles)
snapshot = {'site': get('/api/site'), 'categories': get('/api/categories'),
            'tags': get('/api/tags'), 'articles': articles, 'slides': get('/api/slides')}
(dest / 'src' / 'snapshot.json').write_text(json.dumps(snapshot, ensure_ascii=False), encoding='utf-8')
# Only assets referenced by published content are eligible for the preview.
references = set(re.findall(r'/uploads/[\w./%+@()\-]+', json.dumps(snapshot, ensure_ascii=False)))
for reference in references:
    source = (root / 'data' / reference.lstrip('/')).resolve()
    if not source.is_relative_to((root / 'data' / 'uploads').resolve()):
        raise ValueError('Invalid upload path')
    if not source.is_file(): raise FileNotFoundError(reference)
    target = dest / 'public' / reference.lstrip('/')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
(dest / 'vite.config.js').write_text("import {defineConfig} from 'vite';import vue from '@vitejs/plugin-vue';export default defineConfig({plugins:[vue()]})\n", encoding='utf-8')
main = (dest / 'src' / 'main.js').read_text(encoding='utf-8').replace("import Admin from './Admin.vue'", "import Admin from './PreviewAdmin.vue'")
(dest / 'src' / 'main.js').write_text(main, encoding='utf-8')
(dest / 'src' / 'Admin.vue').unlink()
(dest / 'src' / 'PreviewAdmin.vue').write_text('''<template><main class="about-page"><div class="eyebrow">ITTEXT PREVIEW</div><h1>只读设计预览</h1><p>在线预览支持文章浏览、分类与搜索。管理后台请使用本地完整系统。</p><router-link class="button primary" to="/">返回文章列表</router-link></main></template>''', encoding='utf-8')
(dest / 'src' / 'api.js').write_text('''import data from './snapshot.json'
export async function csrf(){}
export async function api(path,options={}){
 if(options.method&&options.method!=='GET')throw new Error('这是只读设计预览，暂不接受留言或修改。')
 const url=new URL(path,'https://preview.invalid'),p=url.pathname,q=url.searchParams
 if(p==='/site')return data.site
 if(p==='/slides')return data.slides
 if(p==='/categories')return data.categories
 if(p==='/tags')return data.tags
 if(p==='/articles'){
  let items=data.articles.filter(a=>a.kind===(q.get('kind')||'ARTICLE'))
  if(q.get('category'))items=items.filter(a=>String(a.category_id)===q.get('category'))
  if(q.get('tag'))items=items.filter(a=>(a.tags||'').split(',').includes(q.get('tag')))
  if(q.get('q')){const term=q.get('q').toLowerCase();items=items.filter(a=>[a.title,a.summary,a.content].some(v=>(v||'').toLowerCase().includes(term)))}
  items.sort((a,b)=>b.created_at-a.created_at||b.id-a.id)
  const page=Math.max(1,Number(q.get('page'))||1),size=Math.max(1,Math.min(100,Number(q.get('size'))||9))
  return {items:items.slice((page-1)*size,page*size),total:items.length,page,size}
 }
 if(/^\\/articles\\/\\d+\\/comments$/.test(p))return []
 if(p.startsWith('/legacy/')){const a=data.articles.find(a=>String(a.legacy_id)===p.split('/')[2]);if(a)return {id:a.id}}
 if(/^\\/articles\\/\\d+$/.test(p)){const a=data.articles.find(a=>String(a.id)===p.split('/')[2]);if(a)return a}
 throw new Error('内容不存在或预览中未开放此功能')
}
export const date=n=>new Date(Number(n)).toLocaleDateString('zh-CN',{year:'numeric',month:'2-digit',day:'2-digit'})
export const number=n=>Number(n||0).toLocaleString('zh-CN')
''', encoding='utf-8')
blog = (dest / 'src' / 'Blog.vue').read_text(encoding='utf-8')
blog = blog.replace('留言经审核后公开显示', '只读预览，留言暂不可提交').replace(':disabled="sending"', ':disabled="true"').replace('还没有留言，来分享你的想法。', '只读预览暂不展示留言。')
blog = blog.replace('管理后台 <ArrowUpRight', '预览说明 <ArrowUpRight')
blog = blog.replace('</footer>', '</footer><div style="text-align:center;padding:12px;font-size:12px;color:var(--muted)">只读设计预览 · 公开内容快照 · 管理功能请使用本地系统</div>')
(dest / 'src' / 'Blog.vue').write_text(blog, encoding='utf-8')
with urllib.request.urlopen('http://127.0.0.1:8080/feed.xml') as response:
    (dest / 'public' / 'feed.xml').write_bytes(response.read())
(dest / 'README.md').write_text('# IT文档只读设计预览\n\n仅包含公开文章快照和引用附件。不包含后台、数据库、草稿、凭据。\n\n重新生成：运行项目 scripts/prepare-share-preview.py，然后使用原 web/node_modules 中的 Vite 构建。\n', encoding='utf-8')
(dest / '.gitignore').write_text('node_modules/\n', encoding='utf-8')
print(json.dumps({'articles':len(articles),'uploads':len(references),'preview':str(dest)}, ensure_ascii=False))
