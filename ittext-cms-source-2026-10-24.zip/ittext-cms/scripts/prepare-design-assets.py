"""Encode generated art for delivery; no compositing or visual-content edits."""
from pathlib import Path
from PIL import Image
import shutil

root=Path(__file__).resolve().parents[1]
public=root/'web/public/design'
originals=root/'.local/design-source'
mobile=root/'uniapp/src/static/design'
originals.mkdir(parents=True,exist_ok=True)
mobile.mkdir(parents=True,exist_ok=True)
for name in ('hero-study','cover-storage','cover-edge','cover-windows','cover-security','cover-grub'):
    source=public/(name+'.png')
    saved=originals/(name+'.png')
    if source.exists(): shutil.move(str(source),str(saved))
    with Image.open(saved) as image:
        image=image.convert('RGB')
        image.save(public/(name+'.webp'),'WEBP',quality=90,method=6)
        image.thumbnail((1280,480) if name=='hero-study' else (960,400),Image.Resampling.LANCZOS)
        image.save(mobile/(name+'.jpg'),'JPEG',quality=86,optimize=True)
print('Web image bytes:',sum(p.stat().st_size for p in public.glob('*.webp')))
print('Mini-app image bytes:',sum(p.stat().st_size for p in mobile.glob('*.jpg')))
