// Validate a raw npm audit without treating locally backported version findings as a clean scan.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname,'..');
const report = JSON.parse(fs.readFileSync(path.resolve(root,process.argv[2] || 'docs/security/npm-uniapp-remediated.json')));
assert.ok(report.metadata && !report.error,'Missing or failed npm audit');
const allowed = 'https://github.com/advisories/GHSA-vfj7-8cjw-p6xm';
const vulnerabilities = report.vulnerabilities || {};
const memo = new Map();
function onlyBackported(name,trail=new Set()) {
  if (memo.has(name)) return memo.get(name);
  assert.ok(!trail.has(name),'Cyclic advisory references');
  const v=vulnerabilities[name];assert.ok(v && v.via.length,'Unresolved advisory: '+name);
  const next=new Set(trail);next.add(name);
  const valid=v.via.every(x=>typeof x==='string'?onlyBackported(x,next):x.url===allowed && name==='braces');
  memo.set(name,valid);return valid;
}
for(const name of Object.keys(vulnerabilities)) assert.ok(onlyBackported(name),'Unfixed advisory: '+name);
// Exercise the actual dependency resolution and patched parser/walkers, rather than version matching.
require(path.join(root,'uniapp/vendor/braces/security-test.js'));
console.log(JSON.stringify({result:'PASS',rawNpmFindings:report.metadata.vulnerabilities,
  remainingAdvisories:Object.keys(vulnerabilities).length?[allowed]:[],
  disposition:'Source backport verified; upstream-version npm warnings remain visible.'},null,2));
