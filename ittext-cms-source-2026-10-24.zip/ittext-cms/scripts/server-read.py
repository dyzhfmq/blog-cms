"""Read-only SSH inventory/export. Password is requested on stdin and never persisted."""
import sys, pathlib, getpass, json, shlex, hashlib, base64
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.tools/python'))
import paramiko

class PinHost(paramiko.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        fingerprint=base64.b64encode(hashlib.sha256(key.asbytes()).digest()).decode().rstrip('=')
        pin=ROOT/'.local/server-host.sha256';pin.parent.mkdir(exist_ok=True)
        if pin.exists() and pin.read_text()!=fingerprint: raise RuntimeError('服务器主机密钥变更，停止连接')
        if not pin.exists(): pin.write_text(fingerprint)
        print('SSH host SHA256:'+fingerprint,flush=True)

client=paramiko.SSHClient();client.set_missing_host_key_policy(PinHost())
password=getpass.getpass('SSH password: ')
client.connect('47.108.196.248',username='root',password=password,timeout=20,look_for_keys=False,allow_agent=False)
password=None
def run(command):
    _,out,err=client.exec_command(command,timeout=90)
    result=out.read();error=err.read().decode(errors='replace')
    if out.channel.recv_exit_status()!=0: raise RuntimeError(error[:1000])
    return result
try:
    if len(sys.argv)==1 or sys.argv[1]=='inventory':
        print(run("uname -a; ls /www/server/panel/vhost/nginx/; grep -l ittext.cn /www/server/panel/vhost/nginx/*.conf; command -v php; ls /www/server/php/").decode())
    elif sys.argv[1]=='vhost':
        print(run("grep -E 'server_name|root |listen' /www/server/panel/vhost/nginx/ittext.cn.conf; find /www/wwwroot -maxdepth 4 -path '*/zb_users/c_option.php'").decode())
    elif sys.argv[1]=='export':
        # PHP config remains remote. Only explicitly selected content tables are exported.
        site=sys.argv[2];php=sys.argv[3]
        code=r'''$c=include __DIR__.'/zb_users/c_option.php'; if(!is_array($c)){$c=$GLOBALS['option']??[];} $type=$c['ZC_DATABASE_TYPE']??''; $p=$c['ZC_MYSQL_PRE']??'zbp_'; if($type==='sqlite'){$db=new PDO('sqlite:'.__DIR__.'/zb_users/data/'.$c['ZC_SQLITE_NAME']);$p=$c['ZC_SQLITE_PRE']??'zbp_';}else{$db=new PDO('mysql:host='.$c['ZC_MYSQL_SERVER'].';port='.($c['ZC_MYSQL_PORT']??3306).';dbname='.$c['ZC_MYSQL_NAME'].';charset=utf8mb4',$c['ZC_MYSQL_USERNAME'],$c['ZC_MYSQL_PASSWORD']);} if(!preg_match('/^[a-zA-Z0-9_]+$/',$p))exit(2);$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$r=[];foreach(['post','category','tag','comment','upload'] as $t){$r[$t]=$db->query('SELECT * FROM '.$p.$t)->fetchAll(PDO::FETCH_ASSOC);}echo json_encode($r,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);'''
        # __DIR__ in php -r resolves to the selected site working directory.
        raw=run('cd '+shlex.quote(site)+' && '+shlex.quote(php)+' -r '+shlex.quote(code))
        data=json.loads(raw);(ROOT/'data/source').mkdir(parents=True,exist_ok=True)
        (ROOT/'data/source/zblog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({k:len(v) for k,v in data.items()}),flush=True)
        sftp=client.open_sftp()
        # Walk only the user uploads directory; no executable/config files copied.
        import stat
        count=0
        def copy_dir(remote,local):
            global count
            local.mkdir(parents=True,exist_ok=True)
            for entry in sftp.listdir_attr(remote):
                src=remote+'/'+entry.filename;dst=local/entry.filename
                if stat.S_ISDIR(entry.st_mode):copy_dir(src,dst)
                elif stat.S_ISREG(entry.st_mode) and pathlib.Path(entry.filename).suffix.lower() in {'.png','.jpg','.jpeg','.gif','.webp','.bmp','.pdf','.zip','.7z','.rar','.txt','.doc','.docx','.xls','.xlsx','.mp4'}:
                    sftp.get(src,str(dst));count+=1
        copy_dir(site+'/zb_users/upload',ROOT/'data/uploads/legacy')
        print('Downloaded upload files:',count,flush=True)
    else: raise ValueError('Unknown mode')
finally:client.close()
