$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
New-Item -ItemType Directory -Force .local | Out-Null
$javaExe=Join-Path $projectRoot '.tools/java/jdk-21.0.8-lite/bin/java.exe'
if(!(Test-Path -LiteralPath $javaExe)){$javaExe=(Get-Command java -ErrorAction Stop).Source}
$nodeExe=(Get-Command node -ErrorAction Stop).Source
if(!(Test-Path backend/target/cms-1.0.0.jar)){throw 'Build the backend first: mvn -f backend/pom.xml package'}
if(!(Test-Path web/node_modules/vite/bin/vite.js)){throw 'Install frontend dependencies first: cd web; npm ci'}
$ownedProcesses=@()
function EndpointReady([string]$Url,[string]$Pattern){
    try{$response=Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2;return $response.StatusCode -eq 200 -and $response.Content -match $Pattern}catch{return $false}
}
if(!(EndpointReady 'http://127.0.0.1:8080/api/health' 'ittext-cms')){
    $process=Start-Process -FilePath $javaExe -ArgumentList @('-Djdk.net.unixdomain.tmpdir=.local','-jar','backend/target/cms-1.0.0.jar') -WorkingDirectory $projectRoot -WindowStyle Hidden -RedirectStandardOutput '.local/server.out.log' -RedirectStandardError '.local/server.err.log' -PassThru
    $ownedProcesses+=@{id=$process.Id;started=$process.StartTime.ToUniversalTime().ToString('o');path=$javaExe}
}
if(!(EndpointReady 'http://127.0.0.1:5173' '/src/main.js')){
    $process=Start-Process -FilePath $nodeExe -ArgumentList @('node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5173') -WorkingDirectory (Join-Path $projectRoot 'web') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $projectRoot '.local/web.out.log') -RedirectStandardError (Join-Path $projectRoot '.local/web.err.log') -PassThru
    $ownedProcesses+=@{id=$process.Id;started=$process.StartTime.ToUniversalTime().ToString('o');path=$nodeExe}
}
if($ownedProcesses.Count -gt 0){
    $previous=@();if(Test-Path .local/app-processes.json){$previous=@(Get-Content .local/app-processes.json -Raw | ConvertFrom-Json)}
    ConvertTo-Json -InputObject @($previous+$ownedProcesses) | Set-Content .local/app-processes.json -Encoding utf8
}
$isReady=$false
for($attempt=0;$attempt -lt 30;$attempt++){
    if((EndpointReady 'http://127.0.0.1:8080/api/health' 'ittext-cms') -and (EndpointReady 'http://127.0.0.1:5173' '/src/main.js')){$isReady=$true;break}
    Start-Sleep -Seconds 1
}
if(!$isReady){throw 'Startup failed. Check .local/server.err.log, .local/server.out.log and .local/web.err.log'}
Write-Host 'Blog:  http://localhost:5173'
Write-Host 'Admin: http://localhost:5173/admin'
Write-Host 'Account: admin; password file: data/initial-admin-password.txt'
Write-Host 'Stop: powershell -File scripts/stop-local.ps1'
