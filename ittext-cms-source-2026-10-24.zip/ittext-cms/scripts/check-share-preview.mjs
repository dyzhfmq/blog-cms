import fs from 'node:fs'
const base=new URL('../share-preview/ittext-editorial/src/',import.meta.url)
const code=fs.readFileSync(new URL('api.js',base),'utf8').replace("import data from './snapshot.json'",'const data='+fs.readFileSync(new URL('snapshot.json',base),'utf8'))
const {api}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'))
const all=await api('/articles?size=100')
if(all.total!==8)throw Error('Unexpected article count')
for(const a of all.items){if(a.status!=='PUBLISHED')throw Error('Nonpublic content');await api('/articles/'+a.id)}
if((await api('/articles?q=grub')).total!==1)throw Error('Search failed')
if((await api('/articles?kind=PAGE')).total!==1)throw Error('Page missing')
let blocked=false
try{await api('/articles/1/comments',{method:'POST'})}catch{blocked=true}
if(!blocked)throw Error('Writes allowed')
console.log('PASS: public content, search, details and write blocking')
