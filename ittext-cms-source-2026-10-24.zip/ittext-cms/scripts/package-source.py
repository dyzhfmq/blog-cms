"""Create a source-only handover ZIP using explicit roots, without runtime data."""
from pathlib import Path
import hashlib,json,re,zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
excluded={'node_modules','target','dist','.git','__pycache__','.local','.tools'}
files={}
for folder in ['backend','web','uniapp','scripts','docs']:
    for p in (ROOT/folder).rglob('*'):
        rel=p.relative_to(ROOT)
        if not p.is_file() or any(x in excluded for x in rel.parts):continue
        if p.name.startswith('.env') and p.name!='.env.example':continue
        if p.suffix.lower() in {'.log','.pid','.pyc','.key','.pem','.p12','.pfx','.db'}:continue
        files[rel.as_posix()]=p.read_bytes()
for name in ['README.md','.gitignore','.env.example','start-local.cmd','交付报告.md','使用手册.md','开发手册.md','部署手册.md','design-qa.md']:
    files[name]=(ROOT/name).read_bytes()
files['data/.gitkeep']=b''
# The local convenience helper uses a private vault reference; distribute a portable helper.
files['scripts/remote-ops.py']=b'''import os,sys,pathlib,getpass,hashlib,base64
import paramiko
def connect():
 host=os.environ.get('ITTEXT_SSH_HOST','')
 if not host: raise RuntimeError('Set ITTEXT_SSH_HOST before connecting')
 c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.RejectPolicy())
 c.connect(host,username=os.environ.get('ITTEXT_SSH_USER','root'),password=getpass.getpass('SSH password: '),look_for_keys=False,allow_agent=False,timeout=20)
 return c
if __name__=='__main__':
 c=connect()
 try:
  _,o,e=c.exec_command(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8-sig'),timeout=180)
  print(o.read().decode(errors='replace'));print(e.read().decode(errors='replace'),file=sys.stderr);sys.exit(o.channel.recv_exit_status())
 finally:c.close()
'''
secrets=[]
for p in (ROOT/'data').glob('*credentials*.json'):
    try:
        obj=json.loads(p.read_text(encoding='utf-8-sig'))
        secrets.extend(v for k,v in obj.items() if isinstance(v,str) and len(v)>7 and re.search('password|secret|token',k,re.I))
    except (ValueError,OSError):pass
for name,raw in files.items():
    if any(s.encode() in raw for s in secrets) or (name!='scripts/package-source.py' and re.search(rb'dyzhfmq@|gh[pousr]_[A-Za-z0-9]{20}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',raw)):
        raise RuntimeError('Potential credential detected in '+name)
    if name!='scripts/package-source.py' and (b'E:\\obsidian' in raw or b'E:/obsidian' in raw):raise RuntimeError('Private vault reference in '+name)
manifest={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(files.items())}
files['SOURCE-MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
archive=OUT/'ittext-cms-source-2026-10-24.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr('ittext-cms/'+name,raw)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(OUT/(archive.name+'.sha256')).write_text(digest+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':digest},ensure_ascii=False))
