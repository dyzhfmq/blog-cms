import assert from 'node:assert/strict'
import fs from 'node:fs'
import {createRouter,createMemoryHistory} from '../web/node_modules/vue-router/dist/vue-router.mjs'
import {categoryLocation,legacyCategoryRedirect} from '../web/src/category-route.js'
const main=fs.readFileSync(new URL('../web/src/main.js',import.meta.url),'utf8')
const literal=main.match(/path:('\/category\/[^']+')/)[1]
const path=Function('return '+literal)()
const router=createRouter({history:createMemoryHistory(),routes:[{path,component:{}},{path:'/:pathMatch(.*)*',component:{}}]})
router.beforeEach(to=>legacyCategoryRedirect(to))
await router.push('/category/1?page=2')
assert.equal(router.currentRoute.value.params.categoryId,'1')
assert.equal(router.currentRoute.value.query.page,'2')
await router.push('/?category=3&page=2&q=linux')
assert.equal(router.currentRoute.value.path,'/category/3')
assert.deepEqual({...router.currentRoute.value.query},{page:'2',q:'linux'})
assert.deepEqual(categoryLocation({category:3,page:2}),{path:'/category/3',query:{page:2}})
assert.deepEqual(categoryLocation({}),{path:'/',query:{}})
assert.equal(legacyCategoryRedirect({path:'/',query:{id:'10',category:'3'}}),undefined)
console.log('PASS: category matching, old URL redirect, pagination, search parameters, legacy article precedence')
