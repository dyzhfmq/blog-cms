import os,sys,pathlib,getpass,hashlib,base64
import paramiko
def connect():
 host=os.environ.get('ITTEXT_SSH_HOST','')
 if not host: raise RuntimeError('Set ITTEXT_SSH_HOST before connecting')
 c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.RejectPolicy())
 c.connect(host,username=os.environ.get('ITTEXT_SSH_USER','root'),password=getpass.getpass('SSH password: '),look_for_keys=False,allow_agent=False,timeout=20)
 return c
if __name__=='__main__':
 c=connect()
 try:
  _,o,e=c.exec_command(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8-sig'),timeout=180)
  print(o.read().decode(errors='replace'));print(e.read().decode(errors='replace'),file=sys.stderr);sys.exit(o.channel.recv_exit_status())
 finally:c.close()
