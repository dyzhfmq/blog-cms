param([switch]$BackendOnly)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$javaHome=Join-Path $projectRoot '.tools/java/jdk-21.0.8-lite'
if(Test-Path $javaHome){$env:JAVA_HOME=$javaHome;$env:PATH="$javaHome\bin;$env:PATH"}
$maven=Join-Path $projectRoot '.tools/apache-maven-3.9.11/bin/mvn.cmd'
if(!(Test-Path $maven)){$maven='mvn'}
if($BackendOnly){Push-Location $projectRoot;try{New-Item -ItemType Directory -Force .local | Out-Null;$env:JAVA_TOOL_OPTIONS='-Djdk.net.unixdomain.tmpdir=.local';& $maven -f backend/pom.xml spring-boot:run}finally{Pop-Location};exit}
Write-Host '分别在两个终端运行：'
Write-Host '  powershell -ExecutionPolicy Bypass -File scripts/dev.ps1 -BackendOnly'
Write-Host '  cd web; node ../.tools/npm/package/bin/npm-cli.js run dev'
Write-Host '网站：http://localhost:5173  后台：http://localhost:5173/admin'
Write-Host '首次管理员：admin；密码保存在 data/initial-admin-password.txt（请勿提交到版本库）。'
