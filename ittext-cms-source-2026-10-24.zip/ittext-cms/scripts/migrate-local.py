"""Import the local Z-Blog snapshot via authenticated, CSRF-protected CMS API."""
import sys,pathlib,json,re,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.tools/python'))
import requests
from bs4 import BeautifulSoup
base='http://127.0.0.1:8080'
s=requests.Session()
def csrf():
    r=s.get(base+'/api/auth/csrf',timeout=10);r.raise_for_status();return {'X-CSRF-TOKEN':r.json()['token']}
password=(ROOT/'data/initial-admin-password.txt').read_text().strip()
r=s.post(base+'/api/auth/login',json={'username':'admin','password':password},headers=csrf(),timeout=10);r.raise_for_status();password=None
source=json.loads((ROOT/'data/source/zblog.json').read_text(encoding='utf-8'))
r=s.post(base+'/api/admin/import/zblog',json=source,headers=csrf(),timeout=60);r.raise_for_status();report=r.json()
r=s.post(base+'/api/admin/import/zblog',json=source,headers=csrf(),timeout=60);r.raise_for_status();repeated=r.json()
assert repeated['added']==0 and repeated['skipped']==len(source['post']),repeated
data=s.get(base+'/api/admin/articles?size=50',timeout=10).json()
assert data['total']==len(source['post']),data
by_legacy={int(a['legacy_id']):a for a in data['items']}
missing=[];image_urls=[];links=[]
for p in source['post']:
    a=by_legacy[int(p['log_ID'])]
    assert a['title']==p['log_Title'],a['id']
    assert a['status']==('PUBLISHED' if int(p['log_Status'])==0 else 'DRAFT'),a
    assert a['created_at']==int(p['log_PostTime'])*1000,a
    detail=s.get(base+'/api/admin/articles/'+str(a['id']),timeout=10).json()
    soup=BeautifulSoup(detail['content'],'html.parser')
    for node,attr in [('img','src'),('a','href')]:
        for el in soup.find_all(node):
            url=el.get(attr,'')
            if url.startswith('/uploads/'):
                if not (ROOT/'data'/url.lstrip('/')).is_file():missing.append(url)
                else:
                    response=s.get(base+url,timeout=20)
                    assert response.status_code==200,(url,response.status_code)
                    assert hashlib.sha256(response.content).digest()==hashlib.sha256((ROOT/'data'/url.lstrip('/')).read_bytes()).digest(),url
                (image_urls if node=='img' else links).append(url)
    if a['status']=='DRAFT':assert s.get(base+'/api/articles/'+str(a['id']),timeout=10).status_code==404
    else:assert s.get(base+'/api/legacy/'+str(p['log_ID']),timeout=10).json()['id']==a['id']
assert not missing,missing
files=list((ROOT/'data/uploads/legacy').rglob('*'));files=[f for f in files if f.is_file()]
assert len(files)==len(source['upload']),(len(files),len(source['upload']))
public=s.get(base+'/api/articles?size=50',timeout=10).json()
assert public['total']==sum(int(p['log_Status'])==0 and int(p['log_Type'])==0 for p in source['post'])
manifest={str(f.relative_to(ROOT/'data')):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
result={'sourceCounts':{k:len(v) for k,v in source.items()},'import':report,'repeatImport':repeated,'publicArticles':public['total'],'localFiles':len(files),'checkedImageReferences':len(image_urls),'checkedAttachmentLinks':len(links),'missingReferences':missing,'draftsProtected':True,'titlesAndDatesMatch':True,'localFilesSha256':manifest}
(ROOT/'data/migration-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='localFilesSha256'},ensure_ascii=True,indent=2))
