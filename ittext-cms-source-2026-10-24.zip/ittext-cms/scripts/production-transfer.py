import sys,pathlib,tarfile,json,secrets,io
R=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'scripts'))
import importlib.util
spec=importlib.util.spec_from_file_location('remote',R/'scripts/remote-ops.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
if sys.argv[1]=='upload':
 c=m.connect()
 try:
  s=c.open_sftp();s.put(sys.argv[2],sys.argv[3]);s.close();print('Uploaded',pathlib.Path(sys.argv[2]).name)
 finally:c.close()
elif sys.argv[1]=='download':
 c=m.connect()
 try:
  s=c.open_sftp();s.get(sys.argv[2],sys.argv[3]);s.close();print('Downloaded',pathlib.Path(sys.argv[3]).name)
 finally:c.close()
elif sys.argv[1]=='bundle':
 with tarfile.open(R/'.local/production-release.tar.gz','w:gz') as t:
  t.add(R/'backend/target/cms-1.0.0.jar',arcname='cms.jar')
  t.add(R/'web/dist',arcname='web')
  t.add(R/'data/uploads',arcname='data/uploads')
  t.add(R/'data/source/zblog.json',arcname='source/zblog.json')
 print('Bundle prepared')

