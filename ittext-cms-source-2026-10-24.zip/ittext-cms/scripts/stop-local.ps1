$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$processFile=Join-Path $projectRoot '.local/app-processes.json'
if(!(Test-Path -LiteralPath $processFile)){Write-Host 'No recorded app processes.';exit}
$processEntries=@(Get-Content -LiteralPath $processFile -Raw | ConvertFrom-Json)
foreach($entry in $processEntries){
    $process=Get-Process -Id $entry.id -ErrorAction SilentlyContinue
    if($process -and $process.Path -eq $entry.path -and $process.StartTime.ToUniversalTime().ToString('o') -eq $entry.started){Stop-Process -Id $process.Id}
}
Remove-Item -LiteralPath $processFile
Write-Host 'Recorded local app processes stopped. Data retained.'
