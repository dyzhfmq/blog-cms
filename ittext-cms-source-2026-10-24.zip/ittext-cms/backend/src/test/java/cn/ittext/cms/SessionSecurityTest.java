package cn.ittext.cms;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;

@SpringBootTest @AutoConfigureMockMvc
@TestPropertySource(properties={"spring.datasource.url=jdbc:h2:mem:session-security;MODE=MySQL;DATABASE_TO_LOWER=TRUE", "cms.admin-password=test-password-123!", "cms.data-dir=./target/test-session-security"})
class SessionSecurityTest {
    @Autowired MockMvc mvc;@Autowired JdbcTemplate db;@Autowired PasswordEncoder passwords;
    @BeforeEach void reset() {db.update("UPDATE cms_user SET password=? WHERE username='admin'",passwords.encode("test-password-123!"));}
    MockHttpSession login(String password) throws Exception {
        return (MockHttpSession)mvc.perform(post("/api/auth/login").with(csrf()).contentType("application/json")
                .content("{\"username\":\"admin\",\"password\":\""+password+"\"}"))
                .andExpect(status().isOk()).andReturn().getRequest().getSession(false);
    }
    @Test void passwordChangeRevokesBothSessionsAndRequiresNewPassword() throws Exception {
        var first=login("test-password-123!");var second=login("test-password-123!");
        mvc.perform(get("/api/admin/stats").session(second)).andExpect(status().isOk());
        mvc.perform(put("/api/admin/users/password").session(first).with(csrf()).contentType("application/json")
                .content("{\"oldPassword\":\"test-password-123!\",\"password\":\"replacement-password-456!\"}"))
                .andExpect(status().isOk());
        assertTrue(first.isInvalid());
        mvc.perform(get("/api/admin/stats").session(second)).andExpect(status().isUnauthorized());
        assertTrue(second.isInvalid());
        mvc.perform(post("/api/auth/login").with(csrf()).contentType("application/json")
                .content("{\"username\":\"admin\",\"password\":\"test-password-123!\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/admin/stats").session(login("replacement-password-456!"))).andExpect(status().isOk());
    }
    @Test void productionRejectsInsecureTransportAndWildcardOrigins() {
        assertThrows(IllegalStateException.class,()->ProductionSettings.validate(false,"https://blog.example","https://blog.example"));
        assertThrows(IllegalStateException.class,()->ProductionSettings.validate(true,"http://blog.example","https://blog.example"));
        assertThrows(IllegalStateException.class,()->ProductionSettings.validate(true,"https://blog.example","*"));
        assertThrows(IllegalStateException.class,()->ProductionSettings.validate(true,"https://blog.example","https://blog.example/path"));
        assertDoesNotThrow(()->ProductionSettings.validate(true,"https://blog.example","https://blog.example,https://admin.example"));
    }
}
