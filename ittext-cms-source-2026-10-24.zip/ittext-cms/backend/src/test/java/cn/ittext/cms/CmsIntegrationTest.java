package cn.ittext.cms;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.context.TestPropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.hamcrest.Matchers.*;

@SpringBootTest @AutoConfigureMockMvc
@TestPropertySource(properties={"spring.datasource.url=jdbc:h2:mem:test;MODE=MySQL;DATABASE_TO_LOWER=TRUE","cms.admin-password=test-password-123!","cms.data-dir=./target/test-data","cms.wechat-token=test-token"})
class CmsIntegrationTest {
    @Autowired MockMvc mvc;@Autowired JdbcTemplate db;
    @BeforeEach void clear(){db.update("DELETE FROM comment");db.update("DELETE FROM article");db.update("DELETE FROM category");db.update("DELETE FROM import_run");}
    @Test void anonymousCannotReadAdminAndCsrfRequired() throws Exception {
        mvc.perform(get("/api/admin/articles")).andExpect(status().isUnauthorized());
        mvc.perform(post("/api/auth/login").contentType("application/json").content("{\"username\":\"admin\",\"password\":\"test-password-123!\"}")).andExpect(status().isForbidden());
        mvc.perform(post("/api/auth/login").with(csrf()).contentType("application/json").content("{\"username\":\"admin\",\"password\":\"test-password-123!\"}")).andExpect(status().isOk()).andExpect(jsonPath("$.username").value("admin"));
    }
    @Test @WithMockUser(roles="EDITOR") void editorCannotReadSettingsOrImport() throws Exception {
        mvc.perform(get("/api/admin/settings")).andExpect(status().isForbidden());
        mvc.perform(post("/api/admin/import/zblog").with(csrf()).contentType("application/json").content("{}")).andExpect(status().isForbidden());
        mvc.perform(get("/api/admin/articles")).andExpect(status().isOk());
    }
    @Test @WithMockUser(roles="ADMIN") void draftHiddenAndHtmlSanitized() throws Exception {
        String json="{\"title\":\"草稿\",\"content\":\"<script>alert(1)</script><p onclick='bad()'>内容</p>\",\"status\":\"DRAFT\"}";
        mvc.perform(post("/api/admin/articles").with(csrf()).contentType("application/json").content(json)).andExpect(status().isOk());
        long id=db.queryForObject("SELECT id FROM article",Long.class);
        mvc.perform(get("/api/articles/"+id)).andExpect(status().isNotFound());
        mvc.perform(get("/api/articles")).andExpect(jsonPath("$.total").value(0));
        mvc.perform(get("/api/admin/articles/"+id)).andExpect(jsonPath("$.content",not(containsString("script")))).andExpect(jsonPath("$.content",not(containsString("onclick"))));
    }
    @Test @WithMockUser(roles="ADMIN") void zblogImportIsIdempotentAndPreservesDrafts() throws Exception {
        String json="{\"category\":[{\"cate_ID\":7,\"cate_Name\":\"Linux\"}],\"tag\":[{\"tag_ID\":1,\"tag_Name\":\"教程\"}],\"post\":[{\"log_ID\":10,\"log_Title\":\"迁移文章\",\"log_Content\":\"<p>正文</p><img src='https://ittext.cn/zb_users/upload/test.png'>\",\"log_Tag\":\"{1}\",\"log_CateID\":7,\"log_PostTime\":1700000000,\"log_Status\":0},{\"log_ID\":11,\"log_Title\":\"草稿\",\"log_Status\":1}]}";
        mvc.perform(post("/api/admin/import/zblog").with(csrf()).contentType("application/json").content(json)).andExpect(status().isOk()).andExpect(jsonPath("$.added").value(2));
        mvc.perform(post("/api/admin/import/zblog").with(csrf()).contentType("application/json").content(json)).andExpect(status().isOk()).andExpect(jsonPath("$.added").value(0)).andExpect(jsonPath("$.skipped").value(2));
        mvc.perform(get("/api/articles")).andExpect(jsonPath("$.total").value(1)).andExpect(jsonPath("$.items[0].tags").value("教程"));
        long id=db.queryForObject("SELECT id FROM article WHERE legacy_id=10",Long.class);
        mvc.perform(get("/api/articles/"+id)).andExpect(jsonPath("$.content",containsString("/uploads/legacy/test.png"))).andExpect(jsonPath("$.created_at").value(1700000000000L));
        mvc.perform(get("/api/legacy/11")).andExpect(status().isNotFound());
    }
    @Test void webhookWithoutSignatureFails() throws Exception {mvc.perform(get("/api/wechat/callback").param("signature","0".repeat(40)).param("timestamp",String.valueOf(System.currentTimeMillis()/1000)).param("nonce","x").param("echostr","ok")).andExpect(status().isForbidden());}
    @Test void localOriginsAllowedAndOtherOriginsDenied() throws Exception {
        mvc.perform(get("/api/auth/csrf").header("Origin","http://127.0.0.1:5173")).andExpect(status().isOk()).andExpect(header().string("Access-Control-Allow-Origin","http://127.0.0.1:5173"));
        mvc.perform(get("/api/auth/csrf").header("Origin","https://untrusted.example")).andExpect(status().isForbidden());
    }
}
