package cn.ittext.cms;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.web.server.ResponseStatusException;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;

@SpringBootTest @AutoConfigureMockMvc
@TestPropertySource(properties={"spring.datasource.url=jdbc:h2:mem:security;MODE=MySQL;DATABASE_TO_LOWER=TRUE", "cms.admin-password=test-password-123!", "cms.data-dir=./target/test-security", "cms.wechat-token=test-token"})
class SecurityRegressionTest {
    @Autowired MockMvc mvc;
    @Autowired WechatController wechat;
    @Autowired ContentService cms;

    @Test void concurrentAttemptsCannotExceedBudgetAndExpire() throws Exception {
        var limiter = new LoginAttempts();
        var admitted = new AtomicInteger();
        try (var pool = Executors.newFixedThreadPool(20)) {
            var jobs = new ArrayList<Future<?>>();
            for (int i=0;i<100;i++) jobs.add(pool.submit(() -> {
                try {limiter.acquire("one-ip", 1000); admitted.incrementAndGet();}
                catch (ResponseStatusException e) {assertEquals(429, e.getStatusCode().value());}
            }));
            for (var job:jobs) job.get();
        }
        assertEquals(10, admitted.get());
        assertDoesNotThrow(() -> limiter.acquire("one-ip",601000));
    }
    @Test void oversizedJsonIsRejectedEvenWithoutContentLength() throws Exception {
        for (boolean chunked:List.of(false,true)) {
            var req=new org.springframework.mock.web.MockHttpServletRequest() {
                @Override public long getContentLengthLong() {return chunked?-1:super.getContentLengthLong();}
            };
            req.setContentType("application/json");req.setContent("x".repeat(33).getBytes());
            var res=new org.springframework.mock.web.MockHttpServletResponse();
            new JsonRequestLimit(32).doFilter(req,res,(request,response)->fail("oversize request reached application"));
            assertEquals(413,res.getStatus());
        }
    }
    @Test void authenticationFailuresAndRateLimitsAreAudited() throws Exception {
        for(int i=0;i<10;i++) mvc.perform(post("/api/auth/login").with(csrf())
                .with(r->{r.setRemoteAddr("192.0.2.77");return r;}).contentType("application/json")
                .content("{\"username\":\"admin\",\"password\":\"wrong-password\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(post("/api/auth/login").with(csrf()).with(r->{r.setRemoteAddr("192.0.2.77");return r;})
                .contentType("application/json").content("{\"username\":\"admin\",\"password\":\"wrong-password\"}"))
                .andExpect(status().isTooManyRequests());
        assertEquals(10,cms.db.queryForObject("SELECT COUNT(*) FROM audit_log WHERE action=?",Integer.class,"登录失败 192.0.2.77"));
        assertEquals(1,cms.db.queryForObject("SELECT COUNT(*) FROM audit_log WHERE action=?",Integer.class,"登录限速 192.0.2.77"));
    }
    @Test void extremePaginationDoesNotOverflow() throws Exception {
        mvc.perform(get("/api/articles").param("page","2147483647").param("size","50"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()").value(0));
    }
    @Test @WithMockUser(roles="EDITOR") void rejectDisguisedAttachmentsAndHugeImages() throws Exception {
        for (String name:List.of("evil.webp","evil.zip","evil.png"))
            mvc.perform(multipart("/api/admin/media").file(new MockMultipartFile("file",name,"image/webp","<script>alert(1)</script>".getBytes())).with(csrf()))
                    .andExpect(status().isBadRequest());
        var image = new java.awt.image.BufferedImage(1,1,java.awt.image.BufferedImage.TYPE_INT_RGB);
        var out = new java.io.ByteArrayOutputStream();
        javax.imageio.ImageIO.write(image,"png",out);
        mvc.perform(multipart("/api/admin/media").file(new MockMultipartFile("file","ok.png","text/html",out.toByteArray())).with(csrf()))
                .andExpect(status().isOk()).andExpect(jsonPath("$.url").exists());
        // GIF logical screen dimensions: reject before allocating a 65535 x 65535 raster.
        byte[] gif = HexFormat.of().parseHex("474946383961ffffffff800000000000ffffff2c00000000ffffffff0002024401003b");
        assertThrows(ResponseStatusException.class,()->MediaValidation.validate(".gif",gif));
    }
    @Test void legacyAttachmentsAreIsolated() throws Exception {
        java.nio.file.Path uploads=java.nio.file.Path.of("./target/test-security/uploads");
        java.nio.file.Files.writeString(uploads.resolve("test.html"),"<script>alert(1)</script>");
        java.nio.file.Files.write(uploads.resolve("test.png"),new byte[]{1});
        mvc.perform(get("/uploads/test.html").servletPath("/uploads/test.html"))
                .andExpect(status().isOk()).andExpect(header().string("Content-Disposition","attachment"))
                .andExpect(header().string("Content-Security-Policy",org.hamcrest.Matchers.containsString("sandbox")))
                .andExpect(header().string("X-Content-Type-Options","nosniff"));
        mvc.perform(get("/uploads/test.png").servletPath("/uploads/test.png"))
                .andExpect(status().isOk()).andExpect(header().doesNotExist("Content-Disposition"));
    }
    @Test void timestampOverflowCannotBypassFreshness() throws Exception {
        String timestamp=Long.toString(System.currentTimeMillis()/1000+Long.MIN_VALUE), nonce="test";
        var fields=new ArrayList<>(List.of("test-token",timestamp,nonce));Collections.sort(fields);
        String signature=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(String.join("",fields).getBytes(StandardCharsets.UTF_8)));
        var error=assertThrows(ResponseStatusException.class,()->wechat.verify(signature,timestamp,nonce));
        assertEquals(403,error.getStatusCode().value());
    }
    @Test void bcryptLimitUsesBytesAndRichTextLinksAreIsolated() {
        assertFalse(MediaValidation.validPassword("密".repeat(25)));
        assertTrue(MediaValidation.validPassword("密".repeat(24)));
        assertTrue(cms.clean("<a href='https://example.com' target='_blank'>link</a>").contains("noopener noreferrer"));
    }
    @Test @WithMockUser(roles="ADMIN") void malformedSlidesAndOversizedFieldsAreClientErrors() throws Exception {
        mvc.perform(put("/api/admin/slides").with(csrf()).contentType("application/json").content("[null]"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/admin/articles").with(csrf()).contentType("application/json").content("{\"title\":\"test\",\"author\":\""+"a".repeat(121)+"\"}"))
                .andExpect(status().isBadRequest());
    }
}
