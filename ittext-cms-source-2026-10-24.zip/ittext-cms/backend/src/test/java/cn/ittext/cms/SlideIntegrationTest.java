package cn.ittext.cms;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
@SpringBootTest @AutoConfigureMockMvc
@TestPropertySource(properties={"spring.datasource.url=jdbc:h2:mem:slides;MODE=MySQL;DATABASE_TO_LOWER=TRUE","cms.admin-password=test-password-123!","cms.data-dir=./target/test-slides"})
class SlideIntegrationTest {
 @Autowired MockMvc mvc; @Autowired JdbcTemplate db;
 @BeforeEach void clear(){db.update("DELETE FROM setting WHERE name='homeSlides'");}
 @Test void anonymousCannotManage()throws Exception{mvc.perform(get("/api/admin/slides")).andExpect(status().isUnauthorized());}
 @Test @WithMockUser(roles="EDITOR") void editorCannotManage()throws Exception{mvc.perform(put("/api/admin/slides").with(csrf()).contentType("application/json").content("[]")).andExpect(status().isForbidden());}
 @Test @WithMockUser(roles="ADMIN") void persistFilterAndValidate()throws Exception{
  String body="[{\"title\":\"公开广告\",\"description\":\"说明\",\"image\":\"/design/hero-study.webp\",\"link\":\"/article/9\",\"button\":\"阅读\",\"enabled\":true},{\"title\":\"未启用\",\"description\":\"\",\"image\":\"https://example.com/a.png\",\"link\":\"https://example.com\",\"button\":\"\",\"enabled\":false}]";
  mvc.perform(put("/api/admin/slides").contentType("application/json").content(body)).andExpect(status().isForbidden());
  mvc.perform(put("/api/admin/slides").with(csrf()).contentType("application/json").content(body)).andExpect(status().isOk());
  mvc.perform(get("/api/slides")).andExpect(jsonPath("$.length()").value(1)).andExpect(jsonPath("$[0].link").value("/article/9"));
  mvc.perform(get("/api/admin/slides")).andExpect(jsonPath("$.length()").value(2));
  mvc.perform(get("/api/site")).andExpect(jsonPath("$.homeSlides").doesNotExist());
  mvc.perform(put("/api/admin/slides").with(csrf()).contentType("application/json").content(body.replace("/article/9","javascript:alert(1)"))).andExpect(status().isBadRequest());
  mvc.perform(get("/api/slides")).andExpect(jsonPath("$[0].link").value("/article/9"));
  mvc.perform(put("/api/admin/slides").with(csrf()).contentType("application/json").content("[]")).andExpect(status().isOk());
  mvc.perform(get("/api/slides")).andExpect(jsonPath("$.length()").value(0));
 }
}
