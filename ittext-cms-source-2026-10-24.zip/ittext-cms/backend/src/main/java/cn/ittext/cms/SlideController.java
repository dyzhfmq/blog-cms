package cn.ittext.cms;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;

@RestController
public class SlideController {
    final ContentService cms; final ObjectMapper json;
    SlideController(ContentService cms,ObjectMapper json){this.cms=cms;this.json=json;}
    public record Slide(String title,String description,String image,String link,String button,boolean enabled){}
    List<Slide> read(){
        var values=cms.db.queryForList("SELECT setting_value FROM setting WHERE name='homeSlides'",String.class);
        if(values.isEmpty())return List.of(new Slide("把折腾写下来，\n让经验有迹可循。","从 Linux 到 Windows，从网络运维到实用工具。\n记录工作中的问题与答案，分享经过实践的技术笔记。","/design/hero-study.webp","/#articles","开始阅读",true));
        try{return json.readValue(values.getFirst(),new TypeReference<List<Slide>>(){});}catch(Exception e){throw new IllegalStateException("Invalid slide configuration",e);}
    }
    @GetMapping("/api/slides") List<Slide> published(){return read().stream().filter(Slide::enabled).toList();}
    @GetMapping("/api/admin/slides") List<Slide> all(){return read();}
    static boolean safe(String url){return url!=null&&(url.matches("^/(?!/)[^\\\\\\s]*$")||url.matches("^https?://[^\\s\\\\]+$"));}
    @PutMapping("/api/admin/slides") @Transactional
    void save(@RequestBody List<Slide> slides,Authentication user)throws Exception{
        if(slides.size()>12)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"最多设置12张广告");
        for(var s:slides)if(s==null||s.title()==null||s.title().isBlank()||s.title().length()>100||s.description()==null||s.description().length()>300||s.button()==null||s.button().length()>30||!safe(s.image())||!safe(s.link())||s.image().length()>2000||s.link().length()>2000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"请填写有效的标题、图片及站内路径或HTTP(S)链接");
        String value=json.writeValueAsString(slides);
        if(cms.db.update("UPDATE setting SET setting_value=? WHERE name='homeSlides'",value)==0)cms.db.update("INSERT INTO setting(name,setting_value) VALUES('homeSlides',?)",value);
        cms.audit(user.getName(),"更新首页广告 "+slides.size()+" 张");
    }
}
