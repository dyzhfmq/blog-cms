package cn.ittext.cms;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.beans.factory.annotation.Value;
import jakarta.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RestController
public class PublicController {
    final ContentService cms; final String publicUrl;final Map<String,Long> comments=new ConcurrentHashMap<>();
    PublicController(ContentService cms,@Value("${cms.public-url}") String url) {this.cms=cms;this.publicUrl=url;}
    @GetMapping("/api/health") Map<String,Object> health() {return Map.of("status","UP","service","ittext-cms");}
    @GetMapping("/api/site") Map<String,String> site() {return cms.settings();}
    @GetMapping("/api/categories") List<Map<String,Object>> categories() {return cms.db.queryForList("SELECT c.*,(SELECT COUNT(*) FROM article a WHERE a.category_id=c.id AND a.status='PUBLISHED' AND a.kind='ARTICLE') article_count FROM category c ORDER BY sort_order,id");}
    @GetMapping("/api/tags") List<String> tags() {var result=new TreeSet<>(cms.db.queryForList("SELECT name FROM tag",String.class));cms.db.queryForList("SELECT tags FROM article WHERE status='PUBLISHED'",String.class).stream().filter(Objects::nonNull).flatMap(s -> Arrays.stream(s.split(","))).filter(s -> !s.isBlank()).forEach(result::add);return List.copyOf(result);}
    @GetMapping("/api/articles") Map<String,Object> list(@RequestParam(required=false) String q,@RequestParam(required=false) Long category,@RequestParam(required=false) String tag,@RequestParam(defaultValue="ARTICLE") String kind,@RequestParam(defaultValue="1") int page,@RequestParam(defaultValue="9") int size) {return cms.list(q,category,tag,null,kind,page,size,false);}
    @GetMapping("/api/articles/{id}") Map<String,Object> article(@PathVariable long id) {var a=cms.one(id,false);cms.db.update("UPDATE article SET views=views+1 WHERE id=?",id);return a;}
    @GetMapping("/api/legacy/{id}") Map<String,Object> legacy(@PathVariable long id) {var rows=cms.db.queryForList("SELECT id FROM article WHERE legacy_id=? AND status='PUBLISHED'",id);if(rows.isEmpty())throw new ResponseStatusException(HttpStatus.NOT_FOUND);return rows.getFirst();}
    @GetMapping("/api/articles/{id}/comments") List<Map<String,Object>> comments(@PathVariable long id) {cms.one(id,false);return cms.db.queryForList("SELECT id,nickname,content,created_at FROM comment WHERE article_id=? AND status='APPROVED' ORDER BY created_at",id);}
    record Comment(@NotBlank @Size(max=80) String nickname,@NotBlank @Size(max=2000) String content) {}
    @PostMapping("/api/articles/{id}/comments") Map<String,String> comment(@PathVariable long id,@Valid @RequestBody Comment body,HttpServletRequest req) {
        cms.one(id,false);long now=System.currentTimeMillis();
        synchronized(comments) {
            comments.entrySet().removeIf(e -> now-e.getValue()>60000);
            if(comments.size()>=10000 || comments.putIfAbsent(req.getRemoteAddr(),now)!=null)
                throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS,"请一分钟后再留言");
        }
        cms.db.update("INSERT INTO comment(article_id,nickname,content,status,created_at) VALUES(?,?,?,'PENDING',?)",id,body.nickname(),body.content(),now);return Map.of("message","留言已提交，审核后显示");
    }
    static String xml(String text) {return text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    @GetMapping(value="/sitemap.xml",produces=MediaType.APPLICATION_XML_VALUE) String sitemap() {var xml=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">");cms.db.queryForList("SELECT id FROM article WHERE status='PUBLISHED'").forEach(a -> xml.append("<url><loc>").append(xml(publicUrl+"/article/"+a.get("id"))).append("</loc></url>"));return xml.append("</urlset>").toString();}
    @GetMapping(value="/feed.xml",produces=MediaType.APPLICATION_XML_VALUE) String feed() {var xml=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><rss version=\"2.0\"><channel><title>IT文档</title><link>"+xml(publicUrl)+"</link><description>一个IT民工的工作日记</description>");cms.db.queryForList("SELECT id,title,summary FROM article WHERE status='PUBLISHED' ORDER BY created_at DESC LIMIT 20").forEach(a -> xml.append("<item><title>").append(xml(cms.text(a.get("title")))).append("</title><link>").append(xml(publicUrl+"/article/"+a.get("id"))).append("</link><description>").append(xml(cms.text(a.get("summary")))).append("</description></item>"));return xml.append("</channel></rss>").toString();}
}
