package cn.ittext.cms;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import org.springframework.web.filter.OncePerRequestFilter;

/** Multipart limits do not apply to JSON, including chunked migration requests. */
final class JsonRequestLimit extends OncePerRequestFilter {
    private final int maximum;
    JsonRequestLimit(int maximum) { this.maximum = maximum; }
    @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        String type = req.getContentType();
        if (type == null || !(type.toLowerCase(java.util.Locale.ROOT).contains("json"))) {
            chain.doFilter(req,res);return;
        }
        if (req.getContentLengthLong() > maximum) {res.sendError(413);return;}
        byte[] body = req.getInputStream().readNBytes(maximum + 1);
        if (body.length > maximum) {res.sendError(413);return;}
        chain.doFilter(new HttpServletRequestWrapper(req) {
            @Override public ServletInputStream getInputStream() {
                var input = new ByteArrayInputStream(body);
                return new ServletInputStream() {
                    @Override public int read() {return input.read();}
                    @Override public int read(byte[] b,int off,int len) {return input.read(b,off,len);}
                    @Override public boolean isFinished() {return input.available()==0;}
                    @Override public boolean isReady() {return true;}
                    @Override public void setReadListener(ReadListener listener) {throw new UnsupportedOperationException("Synchronous request only");}
                };
            }
            @Override public BufferedReader getReader() throws IOException {return new BufferedReader(new InputStreamReader(getInputStream(),getCharacterEncoding()==null?"UTF-8":getCharacterEncoding()));}
        },res);
    }
}
