package cn.ittext.cms;

import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.authentication.*;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.web.cors.*;
import java.util.List;

@Configuration
public class SecurityConfig {
    @Bean org.springframework.security.core.session.SessionRegistry sessions() {return new org.springframework.security.core.session.SessionRegistryImpl();}
    @Bean org.springframework.security.web.session.HttpSessionEventPublisher sessionEvents() {return new org.springframework.security.web.session.HttpSessionEventPublisher();}
    @Bean PasswordEncoder passwords() { return new BCryptPasswordEncoder(); }
    @Bean UserDetailsService users(JdbcTemplate db) {
        return username -> db.query("SELECT * FROM cms_user WHERE username=?", (rs,i) -> User.withUsername(rs.getString("username")).password(rs.getString("password")).roles(rs.getString("role")).build(), username).stream().findFirst().orElseThrow(() -> new UsernameNotFoundException("账号不存在"));
    }
    @Bean AuthenticationManager authentication(UserDetailsService users, PasswordEncoder encoder) {
        var provider = new DaoAuthenticationProvider(users); provider.setPasswordEncoder(encoder); return new ProviderManager(provider);
    }
    @Bean SecurityFilterChain chain(HttpSecurity http, org.springframework.security.core.session.SessionRegistry sessions, @Value("${cms.allowed-origin}") String origin) throws Exception {
        var cors = new CorsConfiguration(); cors.setAllowedOrigins(java.util.Arrays.stream(origin.split(",")).map(String::strip).toList()); cors.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS")); cors.setAllowedHeaders(List.of("Content-Type","X-CSRF-TOKEN")); cors.setAllowCredentials(true);
        var source = new UrlBasedCorsConfigurationSource(); source.registerCorsConfiguration("/**",cors);
        http.addFilterBefore(new UploadHeaders(), org.springframework.security.web.header.HeaderWriterFilter.class)
            .addFilterAt(new org.springframework.security.web.session.ConcurrentSessionFilter(sessions, event -> {
                event.getResponse().setStatus(401);
                event.getResponse().setContentType("application/json;charset=UTF-8");
                event.getResponse().getWriter().write("{\"message\":\"密码已更新，请重新登录\"}");
            }), org.springframework.security.web.session.ConcurrentSessionFilter.class)
            .addFilterAfter(new JsonRequestLimit(32*1024*1024), org.springframework.security.web.access.intercept.AuthorizationFilter.class)
            .cors(c -> c.configurationSource(source))
            .authorizeHttpRequests(a -> a.requestMatchers("/api/admin/slides/**","/api/admin/settings/**","/api/admin/users/**","/api/admin/import/**","/api/admin/audit").hasRole("ADMIN").requestMatchers("/api/admin/**").hasAnyRole("ADMIN","EDITOR").anyRequest().permitAll())
            .csrf(c -> c.ignoringRequestMatchers("/api/wechat/callback"))
            .exceptionHandling(e -> e.authenticationEntryPoint((req,res,ex) -> res.sendError(401,"请先登录")).accessDeniedHandler((req,res,ex) -> res.sendError(403,"权限不足或安全令牌已失效")))
            .logout(l -> l.logoutUrl("/api/auth/logout").addLogoutHandler((req,res,auth) -> {
                var session=req.getSession(false);if(session!=null)sessions.removeSessionInformation(session.getId());
            }).logoutSuccessHandler((req,res,auth) -> res.setStatus(204)));
        return http.build();
    }
}
