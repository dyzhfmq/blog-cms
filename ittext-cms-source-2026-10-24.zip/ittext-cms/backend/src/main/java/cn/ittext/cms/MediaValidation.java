package cn.ittext.cms;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import javax.imageio.ImageIO;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

final class MediaValidation {
    static void validate(String ext, byte[] data) throws IOException {
        boolean valid = false;
        if (Set.of(".jpg", ".jpeg", ".png", ".gif").contains(ext)) {
            // Inspect dimensions before decoding: a tiny compressed file can describe a huge raster.
            try (var input = ImageIO.createImageInputStream(new ByteArrayInputStream(data))) {
                var readers = ImageIO.getImageReaders(input);
                if (readers.hasNext()) {
                    var reader = readers.next();
                    try {
                        reader.setInput(input);
                        String format = reader.getFormatName().toLowerCase(java.util.Locale.ROOT);
                        String expected = ext.equals(".jpg") ? "jpeg" : ext.substring(1);
                        int width = reader.getWidth(0), height = reader.getHeight(0);
                        valid = format.equals(expected) && width > 0 && height > 0 && (long)width * height <= 25_000_000;
                        if (valid) valid = reader.read(0) != null;
                    } finally { reader.dispose(); }
                }
            } catch (IOException | IllegalArgumentException ex) { valid = false; }
        } else if (ext.equals(".webp")) {
            // JDK ImageIO has no built-in WebP reader. Check the RIFF container and chunk bounds.
            if (data.length >= 20 && ascii(data, 0, 4).equals("RIFF") && ascii(data, 8, 4).equals("WEBP")) {
                var bytes = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
                long size = Integer.toUnsignedLong(bytes.getInt(4));
                long chunk = Integer.toUnsignedLong(bytes.getInt(16));
                valid = size == data.length - 8L && chunk > 0 && chunk <= data.length - 20L
                        && Set.of("VP8 ", "VP8L", "VP8X").contains(ascii(data, 12, 4));
            }
        } else if (ext.equals(".pdf")) valid = data.length >= 5 && ascii(data, 0, 5).equals("%PDF-");
        else if (ext.equals(".zip")) valid = data.length >= 22 && data[0] == 'P' && data[1] == 'K'
                && (data[2] == 3 && data[3] == 4 || data[2] == 5 && data[3] == 6);
        if (!valid) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "文件内容与扩展名不符、文件损坏或图片超过2500万像素");
    }
    private static String ascii(byte[] data, int start, int length) {
        return new String(data, start, length, StandardCharsets.US_ASCII);
    }
    static boolean validPassword(String password) {
        return password != null && password.length() >= 12 && password.getBytes(StandardCharsets.UTF_8).length <= 72;
    }
}
