package cn.ittext.cms;

import java.net.URI;
import java.util.Arrays;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/** Fail closed when the production profile still contains development transport settings. */
@Component @Profile("prod") @Order(-100)
class ProductionSettings implements CommandLineRunner {
    private final Environment env;
    ProductionSettings(Environment env) {this.env=env;}
    @Override public void run(String... args) {
        validate(env.getProperty("server.servlet.session.cookie.secure",Boolean.class,false),
                env.getProperty("cms.public-url",""),env.getProperty("cms.allowed-origin",""));
    }
    static void validate(boolean secure,String publicUrl,String origins) {
        if(!secure || !https(publicUrl,false) || origins.isBlank()
                || Arrays.stream(origins.split(",",-1)).map(String::strip).anyMatch(o -> !https(o,true)))
            throw new IllegalStateException("生产环境需要Secure会话Cookie、HTTPS PUBLIC_URL及明确的HTTPS ALLOWED_ORIGIN");
    }
    private static boolean https(String value,boolean origin) {
        try {
            URI uri=URI.create(value);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost()!=null
                    && !uri.getHost().equalsIgnoreCase("localhost") && uri.getUserInfo()==null
                    && uri.getQuery()==null && uri.getFragment()==null
                    && (!origin || uri.getRawPath().isEmpty());
        } catch(IllegalArgumentException ex) {return false;}
    }
}
