package cn.ittext.cms;

import org.springframework.stereotype.Component;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Value;
import java.nio.file.*;
import java.util.*;

@Component
public class Bootstrap implements CommandLineRunner {
    final JdbcTemplate db; final PasswordEncoder encoder; final String password; final String directory;
    Bootstrap(JdbcTemplate db, PasswordEncoder encoder, @Value("${cms.admin-password}") String password, @Value("${cms.data-dir}") String directory) { this.db=db;this.encoder=encoder;this.password=password;this.directory=directory; }
    public void run(String... args) throws Exception {
        Files.createDirectories(Path.of(directory,"uploads"));
        if(db.queryForObject("SELECT COUNT(*) FROM cms_user",Integer.class)==0) {
            String p=password.isBlank()?UUID.randomUUID()+"aA!":password;
            if(!MediaValidation.validPassword(p)) throw new IllegalStateException("CMS_ADMIN_PASSWORD 至少12位且不超过72字节");
            db.update("INSERT INTO cms_user(username,password,role) VALUES(?,?,?)","admin",encoder.encode(p),"ADMIN");
            if(password.isBlank()) Files.writeString(Path.of(directory,"initial-admin-password.txt"),p,StandardOpenOption.CREATE_NEW);
        }
        var defaults=Map.of("title","IT文档","subtitle","一个IT民工的工作日记","description","记录工作，分享技术，沉淀每一次解决问题的经验。","icp","渝ICP备2021005203号-5","police","渝公网安备50011202504057");
        defaults.forEach((k,v) -> { if(db.queryForObject("SELECT COUNT(*) FROM setting WHERE name=?",Integer.class,k)==0) db.update("INSERT INTO setting(name,setting_value) VALUES(?,?)",k,v); });
    }
}

