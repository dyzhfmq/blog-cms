package cn.ittext.cms;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.nio.file.*;
import java.util.*;

@RestController @RequestMapping("/api/admin")
public class AdminController {
    final ContentService cms;final PasswordEncoder encoder;final Path uploads;final org.springframework.security.core.session.SessionRegistry sessions;
    AdminController(ContentService cms,PasswordEncoder encoder,org.springframework.security.core.session.SessionRegistry sessions,@Value("${cms.data-dir}") String data) {this.cms=cms;this.encoder=encoder;this.sessions=sessions;this.uploads=Path.of(data,"uploads").toAbsolutePath();}
    @GetMapping("/stats") Map<String,Object> stats() {return Map.of("articles",cms.db.queryForObject("SELECT COUNT(*) FROM article WHERE kind='ARTICLE'",Long.class),"published",cms.db.queryForObject("SELECT COUNT(*) FROM article WHERE status='PUBLISHED'",Long.class),"drafts",cms.db.queryForObject("SELECT COUNT(*) FROM article WHERE status='DRAFT'",Long.class),"views",cms.db.queryForObject("SELECT COALESCE(SUM(views),0) FROM article",Long.class),"pending",cms.db.queryForObject("SELECT COUNT(*) FROM comment WHERE status='PENDING'",Long.class));}
    @GetMapping("/articles") Map<String,Object> articles(@RequestParam(required=false) String q,@RequestParam(required=false) Long category,@RequestParam(required=false) String status,@RequestParam(required=false) String kind,@RequestParam(defaultValue="1") int page,@RequestParam(defaultValue="20") int size) {return cms.list(q,category,null,status,kind,page,size,true);}
    @GetMapping("/articles/{id}") Map<String,Object> article(@PathVariable long id) {return cms.one(id,true);}
    @PostMapping("/articles") Map<String,Long> create(@RequestBody Map<String,Object> body,Authentication a) {long id=cms.save(null,body);cms.audit(a.getName(),"创建文章 "+id);return Map.of("id",id);}
    @PutMapping("/articles/{id}") Map<String,Long> update(@PathVariable long id,@RequestBody Map<String,Object> body,Authentication a) {cms.save(id,body);cms.audit(a.getName(),"更新文章 "+id);return Map.of("id",id);}
    @DeleteMapping("/articles/{id}") void archive(@PathVariable long id,Authentication a) {cms.one(id,true);cms.db.update("UPDATE article SET status='ARCHIVED',updated_at=? WHERE id=?",System.currentTimeMillis(),id);cms.audit(a.getName(),"归档文章 "+id);}
    @PostMapping("/categories") void category(@RequestBody Map<String,Object> body,Authentication a) {String name=cms.text(body.get("name")).strip();if(name.isEmpty()||name.length()>120)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"栏目名称无效");cms.db.update("INSERT INTO category(name,parent_id,sort_order) VALUES(?,?,?)",name,cms.number(body.get("parent_id"),0),cms.number(body.get("sort_order"),0));cms.audit(a.getName(),"新增栏目 "+name);}
    @PutMapping("/categories/{id}") void category(@PathVariable long id,@RequestBody Map<String,Object> body) {String name=cms.text(body.get("name")).strip();if(name.isEmpty()||name.length()>120)throw new ResponseStatusException(HttpStatus.BAD_REQUEST);if(cms.db.update("UPDATE category SET name=?,sort_order=? WHERE id=?",name,cms.number(body.get("sort_order"),0),id)==0)throw new ResponseStatusException(HttpStatus.NOT_FOUND);}
    @DeleteMapping("/categories/{id}") void removeCategory(@PathVariable long id) {if(cms.db.queryForObject("SELECT COUNT(*) FROM article WHERE category_id=?",Integer.class,id)>0||cms.db.queryForObject("SELECT COUNT(*) FROM category WHERE parent_id=?",Integer.class,id)>0)throw new ResponseStatusException(HttpStatus.CONFLICT,"栏目中仍有内容或子栏目");cms.db.update("DELETE FROM category WHERE id=?",id);}
    @GetMapping("/comments") List<Map<String,Object>> comments() {return cms.db.queryForList("SELECT c.*,a.title article_title FROM comment c LEFT JOIN article a ON a.id=c.article_id ORDER BY c.created_at DESC LIMIT 500");}
    @PutMapping("/comments/{id}") void moderate(@PathVariable long id,@RequestBody Map<String,String> body,Authentication a) {if(!Set.of("APPROVED","REJECTED","PENDING").contains(body.getOrDefault("status","")))throw new ResponseStatusException(HttpStatus.BAD_REQUEST);cms.db.update("UPDATE comment SET status=? WHERE id=?",body.get("status"),id);cms.audit(a.getName(),"审核评论 "+id);}
    @GetMapping("/settings") Map<String,String> settings() {return cms.settings();}
    @PutMapping("/settings") void settings(@RequestBody Map<String,String> body,Authentication a) {body.forEach((k,v) -> {if(!Set.of("title","subtitle","description","icp","police","wechatName","wechatQr").contains(k)||v==null||v.length()>2000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST);});body.forEach((k,v) -> {if(cms.db.update("UPDATE setting SET setting_value=? WHERE name=?",v,k)==0)cms.db.update("INSERT INTO setting(name,setting_value) VALUES(?,?)",k,v);});cms.audit(a.getName(),"更新站点设置");}
    @GetMapping("/users") List<Map<String,Object>> users() {return cms.db.queryForList("SELECT id,username,role FROM cms_user ORDER BY id");}
    @PostMapping("/users") void user(@RequestBody Map<String,String> body,Authentication a) {String name=body.getOrDefault("username","");String pass=body.getOrDefault("password","");String role=body.getOrDefault("role","EDITOR");if(!name.matches("[a-zA-Z0-9_-]{3,60}")||!MediaValidation.validPassword(pass)||!Set.of("ADMIN","EDITOR").contains(role))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"账号至少3位、密码至少12位且不超过72字节、角色须为ADMIN或EDITOR");cms.db.update("INSERT INTO cms_user(username,password,role) VALUES(?,?,?)",name,encoder.encode(pass),role);cms.audit(a.getName(),"创建账号 "+name);}
    @PutMapping("/users/password") void password(@RequestBody Map<String,String> body,Authentication a,jakarta.servlet.http.HttpServletRequest req) {String old=body.getOrDefault("oldPassword","");String pass=body.getOrDefault("password","");String hash=cms.db.queryForObject("SELECT password FROM cms_user WHERE username=?",String.class,a.getName());if(!encoder.matches(old,hash)||!MediaValidation.validPassword(pass))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"旧密码不正确或新密码需至少12位且不超过72字节");cms.db.update("UPDATE cms_user SET password=? WHERE username=?",encoder.encode(pass),a.getName());cms.audit(a.getName(),"修改密码");
        sessions.getAllPrincipals().stream().filter(p -> p instanceof org.springframework.security.core.userdetails.UserDetails u && u.getUsername().equals(a.getName()))
            .forEach(p -> sessions.getAllSessions(p,false).forEach(org.springframework.security.core.session.SessionInformation::expireNow));
        if(req.getSession(false)!=null)req.getSession(false).invalidate();
        org.springframework.security.core.context.SecurityContextHolder.clearContext();}
    @GetMapping("/audit") List<Map<String,Object>> audit() {return cms.db.queryForList("SELECT * FROM audit_log ORDER BY id DESC LIMIT 200");}
    @GetMapping("/media") List<Map<String,Object>> media() {return cms.db.queryForList("SELECT * FROM media ORDER BY id DESC LIMIT 500");}
    @PostMapping("/media") Map<String,String> upload(@RequestParam MultipartFile file,Authentication a) throws Exception {
        String name=Objects.requireNonNullElse(file.getOriginalFilename(),"file");String ext=name.contains(".")?name.substring(name.lastIndexOf('.')).toLowerCase(Locale.ROOT):"";
        if(!Set.of(".jpg",".jpeg",".png",".gif",".webp",".pdf",".zip").contains(ext)||file.isEmpty())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"仅支持图片、PDF和ZIP");
        if(name.length()>255 || file.getSize()>15L*1024*1024)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"文件名过长或文件超过15MB");
        byte[] data=file.getBytes();MediaValidation.validate(ext,data);
        String stored=UUID.randomUUID()+ext;Files.write(uploads.resolve(stored),data,StandardOpenOption.CREATE_NEW);String url="/uploads/"+stored;
        cms.db.update("INSERT INTO media(name,url,size,created_at) VALUES(?,?,?,?)",name,url,file.getSize(),System.currentTimeMillis());cms.audit(a.getName(),"上传媒体 "+stored);return Map.of("url",url,"name",name);
    }
    @GetMapping("/import/history") List<Map<String,Object>> imports() {return cms.db.queryForList("SELECT * FROM import_run ORDER BY id DESC");}
}

