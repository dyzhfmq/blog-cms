package cn.ittext.cms;

import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

/** Reserve attempts before password verification so concurrent requests cannot bypass the limit. */
final class LoginAttempts {
    private record Window(long started, int attempts) {}
    private final Map<String, Window> windows = new HashMap<>();
    synchronized void acquire(String ip, long now) {
        windows.entrySet().removeIf(e -> now - e.getValue().started() >= 600_000);
        Window current = windows.get(ip);
        if (current == null && windows.size() >= 10_000 || current != null && current.attempts() >= 10)
            throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS, "登录尝试过多，十分钟后重试");
        windows.put(ip, new Window(current == null ? now : current.started(), current == null ? 1 : current.attempts() + 1));
    }
}
