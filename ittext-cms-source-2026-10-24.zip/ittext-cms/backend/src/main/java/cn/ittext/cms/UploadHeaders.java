package cn.ittext.cms;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.springframework.web.filter.OncePerRequestFilter;

/** Also isolates migrated attachments, whose bytes were not validated by the upload API. */
final class UploadHeaders extends OncePerRequestFilter {
    @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        if (req.getServletPath().startsWith("/uploads/")) {
            res.setHeader("Content-Security-Policy", "sandbox; default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
            res.setHeader("X-Content-Type-Options", "nosniff");
            res.setHeader("Referrer-Policy", "no-referrer");
            String path = req.getServletPath().toLowerCase(java.util.Locale.ROOT);
            if (!path.matches(".*\\.(png|jpe?g|gif|webp)$")) res.setHeader("Content-Disposition", "attachment");
        }
        chain.doFilter(req, res);
    }
}
