package cn.ittext.cms;

import org.springframework.stereotype.Service;
import org.springframework.jdbc.core.JdbcTemplate;
import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@Service
public class ContentService {
    final JdbcTemplate db;
    ContentService(JdbcTemplate db) { this.db=db; }
    static final Safelist HTML=Safelist.relaxed().addTags("h1","h2","h3","h4","h5","h6","pre","code","hr","figure","figcaption").addAttributes("code","class").addAttributes("a","target","rel").addAttributes("img","width","height","alt").addProtocols("img","src","http","https");
    String clean(String html) { return Jsoup.clean(html==null?"":html,"https://ittext.cn/",HTML.preserveRelativeLinks(true).addEnforcedAttribute("a","rel","noopener noreferrer"),new org.jsoup.nodes.Document.OutputSettings().prettyPrint(false)); }
    String text(Object value) { return value==null?"":String.valueOf(value); }
    long number(Object value,long fallback) { try { return Long.parseLong(text(value)); } catch(Exception ex) {return fallback;} }
    Map<String,Object> one(long id,boolean admin) {
        var rows=db.queryForList("SELECT a.*,c.name category_name FROM article a LEFT JOIN category c ON a.category_id=c.id WHERE a.id=?"+(admin?"":" AND a.status='PUBLISHED'"),id);
        if(rows.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"文章不存在");
        return rows.getFirst();
    }
    Map<String,Object> list(String q,Long category,String tag,String status,String kind,int page,int size,boolean admin) {
        page=Math.max(1,page);size=Math.min(50,Math.max(1,size));
        var args=new ArrayList<Object>();var where=new StringBuilder(" WHERE 1=1");
        if(!admin) where.append(" AND a.status='PUBLISHED'");
        if(status!=null&&admin&&!status.isBlank()) {where.append(" AND a.status=?");args.add(status);}
        if(kind!=null&&!kind.isBlank()) {where.append(" AND a.kind=?");args.add(kind);}
        if(q!=null&&!q.isBlank()) {where.append(" AND (LOWER(a.title) LIKE ? OR LOWER(a.summary) LIKE ? OR LOWER(a.tags) LIKE ?)");for(int i=0;i<3;i++)args.add("%"+q.toLowerCase(Locale.ROOT)+"%");}
        if(category!=null) {where.append(" AND a.category_id=?");args.add(category);}
        if(tag!=null&&!tag.isBlank()) {where.append(" AND CONCAT(',',a.tags,',') LIKE ?");args.add("%,"+tag+",%");}
        long total=db.queryForObject("SELECT COUNT(*) FROM article a"+where,Long.class,args.toArray());
        args.add(size);args.add(((long)page-1)*size);
        var items=db.queryForList("SELECT a.id,a.legacy_id,a.title,a.summary,a.category_id,a.tags,a.cover,a.status,a.kind,a.author,a.created_at,a.updated_at,a.views,c.name category_name FROM article a LEFT JOIN category c ON a.category_id=c.id"+where+" ORDER BY a.created_at DESC,a.id DESC LIMIT ? OFFSET ?",args.toArray());
        return Map.of("items",items,"total",total,"page",page,"size",size);
    }
    long save(Long id,Map<String,Object> a) {
        String title=text(a.get("title")).strip();String status=text(a.getOrDefault("status","DRAFT"));String kind=text(a.getOrDefault("kind","ARTICLE"));
        if(title.isBlank()||title.length()>300||!Set.of("DRAFT","PUBLISHED","ARCHIVED").contains(status)||!Set.of("ARTICLE","PAGE").contains(kind)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"标题、状态或内容类型无效");
        if(text(a.get("content")).length()>2_000_000 || text(a.get("summary")).length()>1000
                || text(a.get("tags")).length()>1000 || text(a.get("author")).length()>120
                || text(a.get("seo_title")).length()>300 || text(a.get("seo_description")).length()>500)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"内容或字段过长");
        String content=clean(text(a.get("content")));String summary=text(a.get("summary"));
        if(summary.isBlank()) {summary=Jsoup.parse(content).text();summary=summary.substring(0,Math.min(180,summary.length()));}
        long now=System.currentTimeMillis();long cat=number(a.get("category_id"),0);
        if(cat!=0&&db.queryForObject("SELECT COUNT(*) FROM category WHERE id=?",Integer.class,cat)==0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"栏目不存在");
        String cover=text(a.get("cover")); if(cover.length()>1000 || !cover.isBlank()&&!SlideController.safe(cover)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"封面地址无效");
        Object[] values={title,summary,content,cat==0?null:cat,text(a.get("tags")),cover,status,kind,text(a.getOrDefault("author","IT文档")),now,text(a.get("seo_title")),text(a.get("seo_description"))};
        if(id==null) {
            var all=new ArrayList<>(Arrays.asList(values));all.add(now);
            var key=new org.springframework.jdbc.support.GeneratedKeyHolder();
            db.update(connection -> {var ps=connection.prepareStatement("INSERT INTO article(title,summary,content,category_id,tags,cover,status,kind,author,updated_at,seo_title,seo_description,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",java.sql.Statement.RETURN_GENERATED_KEYS);for(int i=0;i<all.size();i++)ps.setObject(i+1,all.get(i));return ps;},key);
            return key.getKey().longValue();
        }
        one(id,true);var all=new ArrayList<>(Arrays.asList(values));all.add(id);
        db.update("UPDATE article SET title=?,summary=?,content=?,category_id=?,tags=?,cover=?,status=?,kind=?,author=?,updated_at=?,seo_title=?,seo_description=? WHERE id=?",all.toArray());return id;
    }
    void audit(String user,String action) {db.update("INSERT INTO audit_log(username,action,created_at) VALUES(?,?,?)",user,action,System.currentTimeMillis());}
    Map<String,String> settings() {var result=new LinkedHashMap<String,String>();db.query("SELECT * FROM setting WHERE name <> 'homeSlides'",rs -> {result.put(rs.getString("name"),rs.getString("setting_value"));});return result;}
}

