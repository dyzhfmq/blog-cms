package cn.ittext.cms;

import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.config.annotation.*;
import java.nio.file.Path;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Value("${cms.data-dir}") String directory;
    @Override public void addResourceHandlers(ResourceHandlerRegistry registry) {registry.addResourceHandler("/uploads/**").addResourceLocations(Path.of(directory,"uploads").toAbsolutePath().toUri().toString()).setCachePeriod(3600);}
}
