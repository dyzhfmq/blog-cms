package cn.ittext.cms;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;
import java.security.*;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilderFactory;

@RestController @RequestMapping("/api/wechat")
public class WechatController {
    final ContentService cms;final String token;final String url;final String appId;final String miniId;
    WechatController(ContentService cms,@Value("${cms.wechat-token}") String token,@Value("${cms.public-url}") String url,@Value("${cms.wechat-app-id}") String appId,@Value("${cms.mini-app-id}") String miniId) {this.cms=cms;this.token=token;this.url=url;this.appId=appId;this.miniId=miniId;}
    void verify(String signature,String timestamp,String nonce) throws Exception {
        if(token.isBlank())throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"尚未配置公众号 Token");
        if(timestamp.length()>20||nonce.length()>100||signature.length()!=40)throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        long time;try{time=Long.parseLong(timestamp);}catch(Exception e){throw new ResponseStatusException(HttpStatus.FORBIDDEN);}
        if(time < System.currentTimeMillis()/1000-600 || time > System.currentTimeMillis()/1000+600)throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        var fields=new ArrayList<>(List.of(token,timestamp,nonce));Collections.sort(fields);
        String expected=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(String.join("",fields).getBytes(StandardCharsets.UTF_8)));
        if(!MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII),signature.getBytes(StandardCharsets.US_ASCII)))throw new ResponseStatusException(HttpStatus.FORBIDDEN);
    }
    @GetMapping(value="/callback",produces=MediaType.TEXT_PLAIN_VALUE) String handshake(@RequestParam String signature,@RequestParam String timestamp,@RequestParam String nonce,@RequestParam String echostr) throws Exception {verify(signature,timestamp,nonce);return echostr;}
    @PostMapping(value="/callback",produces=MediaType.APPLICATION_XML_VALUE) String message(@RequestParam String signature,@RequestParam String timestamp,@RequestParam String nonce,@RequestBody String body) throws Exception {
        verify(signature,timestamp,nonce);if(body.length()>30000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        var factory=DocumentBuilderFactory.newInstance();factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);factory.setFeature("http://xml.org/sax/features/external-general-entities",false);factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);factory.setXIncludeAware(false);factory.setExpandEntityReferences(false);
        var doc=factory.newDocumentBuilder().parse(new java.io.ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
        if(doc.getElementsByTagName("Encrypt").getLength()>0)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"当前接入仅支持明文模式，请配置后使用");
        java.util.function.Function<String,String> field=k -> doc.getElementsByTagName(k).getLength()==0?"":doc.getElementsByTagName(k).item(0).getTextContent();
        String query=field.apply("Content").strip();String reply;
        if(field.apply("MsgType").equals("event")&&field.apply("Event").equals("subscribe"))reply="欢迎关注 IT文档！发送关键词搜索技术文章，或访问："+url;
        else if(field.apply("MsgType").equals("text")) {
            var results=cms.list(query,null,null,null,"ARTICLE",1,5,false);
            @SuppressWarnings("unchecked") var rows=(List<Map<String,Object>>)results.get("items");
            reply=rows.isEmpty()?"没有找到相关文章，试试 Linux、Windows 或交换机。":String.join("\n\n",rows.stream().map(a -> a.get("title")+"\n"+url+"/article/"+a.get("id")).toList());
        } else return "success";
        return "<xml><ToUserName>"+PublicController.xml(field.apply("FromUserName"))+"</ToUserName><FromUserName>"+PublicController.xml(field.apply("ToUserName"))+"</FromUserName><CreateTime>"+System.currentTimeMillis()/1000+"</CreateTime><MsgType>text</MsgType><Content>"+PublicController.xml(reply)+"</Content></xml>";
    }
    @GetMapping("/status") Map<String,Object> status() {return Map.of("officialAccountConfigured",!token.isBlank()&&!appId.isBlank(),"miniProgramConfigured",!miniId.isBlank(),"callbackMode","plaintext","callbackPath","/api/wechat/callback");}
    @GetMapping("/menu-template") Map<String,Object> menu() {return Map.of("button",List.of(Map.of("type","view","name","最新文章","url",url),Map.of("type","view","name","技术资料","url",url+"/?category=3"),Map.of("type","view","name","关于本站","url",url+"/about")));}
}
