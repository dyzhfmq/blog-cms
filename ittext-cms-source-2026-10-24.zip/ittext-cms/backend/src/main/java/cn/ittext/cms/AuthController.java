package cn.ittext.cms;

import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.*;
import org.springframework.security.core.context.*;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    final AuthenticationManager manager;
    final ContentService cms;
    final org.springframework.security.core.session.SessionRegistry sessions;
    final LoginAttempts attempts=new LoginAttempts();
    AuthController(AuthenticationManager manager,ContentService cms,org.springframework.security.core.session.SessionRegistry sessions) { this.manager=manager;this.cms=cms;this.sessions=sessions; }
    record Login(@NotBlank @Size(max=60) String username,@NotBlank @Size(max=200) String password) {}
    @GetMapping("/csrf") Map<String,String> csrf(CsrfToken token) { return Map.of("token",token.getToken(),"headerName",token.getHeaderName()); }
    @PostMapping("/login") Map<String,Object> login(@Valid @RequestBody Login body,HttpServletRequest req,HttpServletResponse res) {
        String ip=req.getRemoteAddr(); long now=System.currentTimeMillis();
        try { attempts.acquire(ip,now); } catch(ResponseStatusException e) {cms.audit("-","登录限速 "+ip);throw e;}
        try {
            var auth=manager.authenticate(UsernamePasswordAuthenticationToken.unauthenticated(body.username(),body.password()));
            if(req.getSession(false)!=null) {sessions.removeSessionInformation(req.getSession(false).getId());req.changeSessionId();}
            var context=SecurityContextHolder.createEmptyContext();context.setAuthentication(auth);SecurityContextHolder.setContext(context);
            new HttpSessionSecurityContextRepository().saveContext(context,req,res);cms.audit(auth.getName(),"登录成功 "+ip);
            sessions.registerNewSession(req.getSession().getId(),auth.getPrincipal());
            return Map.of("username",auth.getName(),"roles",auth.getAuthorities());
        } catch(AuthenticationException ex) { cms.audit("-","登录失败 "+ip);throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"账号或密码错误"); }
    }
    @GetMapping("/me") Map<String,Object> me(Authentication auth) {
        if(auth==null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        return Map.of("username",auth.getName(),"roles",auth.getAuthorities());
    }
}
