package cn.ittext.cms;

import com.fasterxml.jackson.databind.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.Authentication;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;
import java.util.regex.*;
import java.nio.file.*;
import org.springframework.beans.factory.annotation.Value;

@RestController @RequestMapping("/api/admin/import")
public class ImportController {
    final ContentService cms;final ObjectMapper mapper;
    @Value("${cms.data-dir}") String directory;
    ImportController(ContentService cms,ObjectMapper mapper) {this.cms=cms;this.mapper=mapper;}
    @PostMapping("/zblog") @Transactional
    Map<String,Object> importData(@RequestBody JsonNode data,Authentication auth) throws Exception {
        if(!data.path("post").isArray()||!data.path("category").isArray()||data.path("post").size()>50000)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"无效 Z-Blog 导出文件");
        int added=0,skipped=0;var tags=new HashMap<Long,String>();
        for(var t:data.path("tag")) {
            tags.put(t.path("tag_ID").asLong(),t.path("tag_Name").asText());
            if(cms.db.queryForObject("SELECT COUNT(*) FROM tag WHERE legacy_id=?",Integer.class,t.path("tag_ID").asLong())==0)cms.db.update("INSERT INTO tag(legacy_id,name) VALUES(?,?)",t.path("tag_ID").asLong(),t.path("tag_Name").asText());
        }
        var categoryMap=new HashMap<Long,Long>();
        for(var c:data.path("category")) {
            long old=c.path("cate_ID").asLong();
            if(cms.db.queryForObject("SELECT COUNT(*) FROM category WHERE legacy_id=?",Integer.class,old)==0)cms.db.update("INSERT INTO category(legacy_id,name,parent_id,sort_order) VALUES(?,?,0,?)",old,c.path("cate_Name").asText(),c.path("cate_Order").asInt());
            categoryMap.put(old,cms.db.queryForObject("SELECT id FROM category WHERE legacy_id=?",Long.class,old));
        }
        for(var c:data.path("category"))cms.db.update("UPDATE category SET parent_id=? WHERE legacy_id=?",categoryMap.getOrDefault(c.path("cate_ParentID").asLong(),0L),c.path("cate_ID").asLong());
        for(var p:data.path("post")) {
            long old=p.path("log_ID").asLong();if(cms.db.queryForObject("SELECT COUNT(*) FROM article WHERE legacy_id=?",Integer.class,old)>0){skipped++;continue;}
            String content=localize(p.path("log_Content").asText());String intro=cms.clean(localize(p.path("log_Intro").asText()));
            String summary=org.jsoup.Jsoup.parse(intro.isBlank()?content:intro).text();summary=summary.substring(0,Math.min(180,summary.length()));
            var selectedTags=new ArrayList<String>();var m=Pattern.compile("\\d+").matcher(p.path("log_Tag").asText());while(m.find()){String t=tags.get(Long.parseLong(m.group()));if(t!=null)selectedTags.add(t);}
            var html=org.jsoup.Jsoup.parse(content);var img=html.selectFirst("img[src]");String cover=img==null?"":img.attr("src");
            var a=new LinkedHashMap<String,Object>();a.put("title",p.path("log_Title").asText());a.put("summary",summary);a.put("content",content);a.put("category_id",categoryMap.getOrDefault(p.path("log_CateID").asLong(),0L));a.put("tags",String.join(",",selectedTags));a.put("cover",cover);a.put("status",p.path("log_Status").asInt()==0?"PUBLISHED":"DRAFT");a.put("kind",p.path("log_Type").asInt()==1?"PAGE":"ARTICLE");a.put("author","IT文档");
            long id=cms.save(null,a);long time=p.path("log_PostTime").asLong()*1000;
            long updated=p.path("log_UpdateTime").asLong(p.path("log_PostTime").asLong())*1000;
            cms.db.update("UPDATE article SET legacy_id=?,created_at=?,updated_at=?,views=?,source_url=? WHERE id=?",old,time,updated,p.path("log_ViewNums").asLong(),"https://ittext.cn/?id="+old,id);added++;
        }
        int commentCount=0;
        for(var c:data.path("comment")) {
            long legacy=c.path("comm_ID").asLong();if(cms.db.queryForObject("SELECT COUNT(*) FROM comment WHERE legacy_id=?",Integer.class,legacy)>0)continue;
            var ids=cms.db.queryForList("SELECT id FROM article WHERE legacy_id=?",Long.class,c.path("comm_LogID").asLong());if(ids.isEmpty())continue;
            cms.db.update("INSERT INTO comment(legacy_id,article_id,nickname,content,status,created_at) VALUES(?,?,?,?,'PENDING',?)",legacy,ids.getFirst(),c.path("comm_Name").asText(),org.jsoup.Jsoup.parse(c.path("comm_Content").asText()).text(),c.path("comm_PostTime").asLong()*1000);commentCount++;
        }
        int mediaCount=0;var missing=new ArrayList<String>();Path root=Path.of(directory,"uploads","legacy");var files=new HashMap<String,Path>();
        if(Files.isDirectory(root))try(var stream=Files.walk(root)){stream.filter(Files::isRegularFile).forEach(p -> files.put(p.getFileName().toString(),p));}
        for(var u:data.path("upload")) {
            String name=u.path("ul_Name").asText();Path file=files.get(name);if(file==null){missing.add(name);continue;}
            String path="/uploads/legacy/"+root.relativize(file).toString().replace('\\','/');
            if(cms.db.queryForObject("SELECT COUNT(*) FROM media WHERE url=?",Integer.class,path)==0){cms.db.update("INSERT INTO media(name,url,size,created_at) VALUES(?,?,?,?)",u.path("ul_SourceName").asText(name),path,Files.size(file),u.path("ul_PostTime").asLong()*1000);mediaCount++;}
        }
        var report=Map.<String,Object>of("added",added,"skipped",skipped,"comments",commentCount,"sourcePosts",data.path("post").size(),"categories",data.path("category").size(),"tags",tags.size(),"mediaAdded",mediaCount,"missingFiles",missing,"source","https://ittext.cn");
        cms.db.update("INSERT INTO import_run(source,report,created_at) VALUES(?,?,?)","https://ittext.cn",mapper.writeValueAsString(report),System.currentTimeMillis());cms.audit(auth.getName(),"导入旧站：新增 "+added+"，跳过 "+skipped);return report;
    }
    String localize(String content) {
        return content.replaceAll("https?://(?:www\\.)?ittext\\.cn/zb_users/upload/","/uploads/legacy/").replace("{#ZC_BLOG_HOST#}zb_users/upload/","/uploads/legacy/").replace("/zb_users/upload/","/uploads/legacy/").replaceAll("https?://(?:www\\.)?ittext\\.cn/\\?id=(\\d+)","/?id=$1");
    }
}
