# IT文档 CMS

开发交接：[开发手册](开发手册.md) · [部署手册](部署手册.md)。源码交付包通过 `python scripts/package-source.py` 生成到 `delivery/`，不包含运行数据和凭据。

2026-10-24：网站分类地址已更新为 `/category/分类ID`，生产旧查询地址执行301跳转并保留分页参数，见 [分类地址说明](docs/category-urls-2026-10-24.md)。

根据现有 ittext.cn 开发的本地博客系统：Spring Boot 3.5 / Java 21 REST API、Vue 3 网站与管理后台、Uni-app Vue 3 H5 与微信小程序。

## 项目结构

| 路径 | 内容 |
| --- | --- |
| `backend/` | 文章/页面、分类、标签、审核评论、媒体、角色、站点设置、导入、日志、公众号回调 |
| `web/` | 响应式博客与 `/admin` 管理后台 |
| `uniapp/` | 小程序/H5：首页、分类、搜索、分页、详情、分享 |
| `scripts/` | 本地启动、SSH只读导出、迁移与一致性核验 |
| `data/` | 忽略提交的本地数据库、原始快照、附件、初始密码及核验报告 |
| `docs/` | 运行、部署、微信接入与验收说明 |

本机双击 `start-local.cmd` 启动。开发启动见 [docs/deploy.md](docs/deploy.md)，微信平台配置见 [docs/wechat.md](docs/wechat.md)。本地默认网站 `http://localhost:5173`，后台 `http://localhost:5173/admin`，API `http://127.0.0.1:8080/api/health`。

首次管理员为 `admin`，密码在 `data/initial-admin-password.txt`。数据与密钥均不进入源码。现有线上网站仅被只读访问。

交付资料：[交付报告](交付报告.md) · [使用手册](使用手册.md)。包含交付范围、迁移与验收结果、日常操作、备份恢复及待上线事项。

Product Design 第一稿视觉升级记录见 [design-qa.md](design-qa.md)，新素材与提示词见 [docs/design/assets.md](docs/design/assets.md)。网站采用书桌场景与图文文章列表；后续已增加可编辑首页幻灯片广告，管理员可通过 `/admin/slides` 管理，见 [广告说明](docs/home-ads.md)。
