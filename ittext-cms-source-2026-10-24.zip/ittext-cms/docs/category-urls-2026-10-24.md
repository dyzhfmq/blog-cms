# 分类伪静态地址（2026-10-24）

已发布到 https://ittext.cn 。

- 分类路径由 `/?category=1` 改为 `/category/1`，API仍使用原分类查询参数。
- 电脑版导航、手机展开导航、热门分类、关于页分类卡片使用真实新路径 href；分类筛选与分页也使用新路径。
- 本地开发通过前端路由兼容旧参数；生产 Nginx 对首页旧分类参数执行301，去掉 category 参数并保留其他参数。
- 示例：`/?category=3&page=2` → `/category/3?page=2`；`/?q=linux&category=3&page=2` → `/category/3?q=linux&page=2`。
- 带旧文章 id 的请求保留文章映射优先级，不误跳分类。
- 页面更新分类标题、description及canonical；当前仍为Vue SPA，metadata由前端渲染，本次没有实施SSR。

验证：`node scripts/check-category-routes.mjs` 通过，Vue生产构建通过。真实HTTPS验证301及参数保留、新路径200。浏览器直接打开/刷新 `/category/3` 显示技术资料2篇，点击Linux跳转 `/category/7` 显示3篇，导航 href 为新路径，错误日志为空。

本次仅更新前端与Nginx，无数据库变更，无后端重启。生产备份：`/var/backups/ittext/category-url-20261024-083653/`，包含原前端和Nginx配置。新map文件位于 `/etc/nginx/conf.d/ittext-category-maps.conf`，本地模板见 `docs/nginx/category-url-maps.conf`。

回退时先另存当前版本，再恢复备份前端及 `ittext.conf`，移出本次新增maps配置，执行 `nginx -t` 后reload。前端和配置需一起回退。

![生产分类页面](screenshots/production-category-2026-10-24.png)
