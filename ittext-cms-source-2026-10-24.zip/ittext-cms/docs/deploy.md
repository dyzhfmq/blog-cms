# 本地运行与部署

## 开发环境

本机已完成构建时，双击根目录 `start-local.cmd` 即可启动网站和后端。此脚本在后台隐藏运行进程，日志位于 `.local/`；结束使用时运行 `powershell -File scripts/stop-local.ps1`。它只停止该启动脚本记录且进程路径与启动时间仍匹配的进程，不触碰其他服务。

Java 21、Maven 3.9+、Node 22+。本次会话工具安装在忽略目录 `.tools/`，并不修改系统全局 Java。若工具不存在，安装上述版本后使用标准 mvn/npm 命令。

在项目根目录运行后端（工作目录必须为项目根，数据在 `data/`）：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/dev.ps1 -BackendOnly
```

另一个终端启动网站：

```powershell
cd web
node ../.tools/npm/package/bin/npm-cli.js run dev
```

打开 `http://localhost:5173` 与 `http://localhost:5173/admin`。首次账号 `admin`，随机密码在 `data/initial-admin-password.txt`。也可首次启动前设置 `CMS_ADMIN_PASSWORD`（至少12位）。首次密码文件仅用于初始化，并不会在重启时重设已有账号。

后端默认 H2 文件数据库，数据持久化在 `data/cms.mv.db`。数据库与 `data/uploads` 一并备份。不要在程序运行中直接复制 H2 文件，先停止后端再备份整个 `data/`。`.env.example` 是环境变量示例，Spring Boot 不会自动加载 `.env`。

本机沙箱的 TEMP 目录过长，会导致 JDK 内部 Unix socket 回环连接失败。启动脚本已使用 `-Djdk.net.unixdomain.tmpdir=.local` 解决；直接运行 JAR 时，在项目根目录先创建 `.local`，再运行 `java -Djdk.net.unixdomain.tmpdir=.local -jar backend/target/cms-1.0.0.jar`。

## 构建

```text
mvn -f backend/pom.xml verify
mvn -f backend/pom.xml package
cd web
npm ci
npm run build
cd ../uniapp
npm ci
npm run build:h5
npm run build:mp-weixin
```

后端产物 `backend/target/cms-1.0.0.jar`，网站 `web/dist`，小程序 `uniapp/dist/build/mp-weixin`。后端与前端独立部署。生产环境建议 MySQL 8+，先创建 `utf8mb4` 数据库，再配置 `DB_URL`/`DB_USER`/`DB_PASSWORD`。本项目建表脚本支持 H2 MySQL 模式及 MySQL；MySQL 本次若未实际运行，不视为已验证。

## Nginx 示例

在预发布域名验收后再进行正式站点切换。现有 ittext.cn 没有被本次开发修改。

```nginx
server {
    listen 443 ssl;
    server_name your-new-domain.example;
    # ssl_certificate /path/fullchain.pem;
    # ssl_certificate_key /path/privkey.pem;
    root /opt/ittext/web/dist;
    client_max_body_size 16m;
    location / { try_files $uri $uri/ /index.html; }
    location /api/ { proxy_pass http://127.0.0.1:8080; proxy_set_header Host $host; }
    location /uploads/ { proxy_pass http://127.0.0.1:8080; }
    location = /feed.xml { proxy_pass http://127.0.0.1:8080; }
    location = /sitemap.xml { proxy_pass http://127.0.0.1:8080; }
}
```

正式 HTTPS 设置 `COOKIE_SECURE=true`、`PUBLIC_URL=https://你的域名`、`ALLOWED_ORIGIN=https://你的域名`。后端绑定127.0.0.1，只允许反向代理访问，不对外开放 H2 控制台。上传目录只提供静态文件，不交给 PHP 执行。系统使用 Cookie 会话、CSRF、BCrypt，管理员和编辑权限不同，默认不信任客户端转发 IP。

正式部署另需启用 `SPRING_PROFILES_ACTIVE=prod`，使生产配置校验生效；该模式默认Secure Cookie和30分钟会话，缺少有效HTTPS公开地址与明确HTTPS跨域来源时拒绝启动。修改密码会撤销该账号全部已登记会话并要求重新登录。该撤销和登录限速目前针对单实例，多实例部署需共享机制。后续依赖补丁与兼容层维护见 [修复复测](security/remediation-followup.md)。Uni-app使用本地workspace回补包，必须连同`uniapp/vendor/braces`和`uniapp/build`复制，按锁文件执行npm ci；不得仅复制package.json。

2026-10-21安全修复后，JSON请求最多32MB，multipart请求仍最多16MB（单文件15MB）。上例Nginx的16MB限制更严格；如需迁移16–32MB的JSON，可临时对导入接口单独设置32MB，不要全局取消限额。密码至少12字符且UTF-8编码不超过72字节。登录同连接IP十分钟最多10次尝试，包括成功登录；多用户经反向代理可能共享限额，生产应配套可信代理和共享网关限流。

`/uploads/`应继续转发后端，使历史及新附件带有sandbox CSP与nosniff，非图片强制下载；直接从Nginx/CDN读取文件时必须复制等效策略。新上传图片最多2500万像素，WebP做容器校验；PDF和ZIP按附件下载，未实现杀毒扫描。安全评估、验证证据和剩余依赖风险见 [安全审计记录](security/GB-T-39412-2020-audit.md)。

## 内容迁移与核验

`scripts/server-read.py` 通过交互输入密码执行只读导出，密码不写入脚本。首次服务器指纹记在 `.local/server-host.sha256`，变更则拒绝连接。

```text
python scripts/server-read.py export /www/wwwroot/ittext.cn /www/server/php/80/bin/php
python scripts/migrate-local.py
```

Python 依赖：paramiko、requests、beautifulsoup4（本次安装在 `.tools/python`）。原始内容 `data/source/zblog.json`，附件 `data/uploads/legacy`，核验报告 `data/migration-report.json`。JSON 包括草稿，应作为私人备份保管。导入不导出老站账号密码或数据库配置。

导入事务保留原 ID 映射、栏目树、全部标签、发布时间、更新时间、阅读数、页面/文章类型与草稿；替换正文内原站上传地址为本地路径。旧 `/?id=N` 由前端解析跳转。重复导入跳过已存在文章，保护新系统编辑；源站后续文章更新不会自动覆盖，需要另外确认同步策略。附件目录按原目录下载，允许常见图片、PDF、压缩包、文档、文本和视频格式，其余类型不会执行或复制。本次全部上传文件均在允许列表内。

管理后台“内容迁移”也能上传该 JSON。迁移报告包含丢失文件列表、数量和本地 SHA-256 校验；核验脚本验证所有文章标题、状态、时间、旧链接及正文中的本地媒体 HTTP 字节一致性。

网站是 Vue SPA：提供页面 meta、RSS、sitemap，但没有服务端渲染。搜索引擎首屏直出 HTML 与原 URL 的服务端301策略可在正式域名切换前单独完善。

## 已部署生产环境（2026-10-21）

网站 https://ittext.cn ，后台 https://ittext.cn/admin 。采用 Java 21 + MySQL 8.4 + Nginx + systemd 原生部署。管理员凭据、备份恢复、服务路径及业务验收结果见 [生产部署记录](production-deployment-2026-10-21.md)。生产管理员密码使用独立随机值，不同于上文的本地初始密码。

