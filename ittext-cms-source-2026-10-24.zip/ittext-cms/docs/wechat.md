# 微信接入

本地完成 Uni-app H5/微信小程序源码与共用阅读 API。公众号提供明文回调验签、关注欢迎语、关键词搜索、菜单 JSON 模板。账号参数尚未提供，不能视为已在微信平台上线或通过真机验收。

## 微信公众号

1. 准备公众号 AppID、自定义 Token 与有 HTTPS 的服务域名。将 `WECHAT_TOKEN`、`WECHAT_APP_ID`、`PUBLIC_URL` 作为后端环境变量配置。
2. 微信公众平台服务器配置填写 `https://你的域名/api/wechat/callback`、同一 Token。当前代码支持**明文模式**，不支持加密模式；不要将加密回调直接指向该接口。
3. 平台启用前校验 URL，成功返回 echostr。关注后自动欢迎，发关键词返回至多5篇已发布文章的链接。
4. `/api/wechat/menu-template` 返回三个 view 菜单的 JSON。正式发布菜单需要公众号的接口权限和 access_token；可在公众平台配置同样菜单。项目不会使用未提供的密钥自动调用微信发布。
5. 公众号 H5 直接访问 Vue 网站，不依赖网页授权。当前没有实现公众号素材同步、群发、支付、网页 OAuth 或 JS-SDK 分享签名；这些并非当前阅读与博客 CMS 必需流程。

## 微信小程序

1. 把小程序 AppID 写入 `uniapp/src/manifest.json` 的 `mp-weixin.appid`。
2. 复制 `uniapp/.env.example` 为 `.env.production`，设置 `VITE_API_BASE=https://你的服务域名`（不带尾斜杠）。客户端只有 API 地址与公开 AppID，不放 AppSecret。
3. 在 `uniapp` 执行 `npm ci` 和 `npm run build:mp-weixin`；微信开发者工具导入 `uniapp/dist/build/mp-weixin`。
4. 公众平台配置 request、downloadFile、图片资源的 HTTPS 合法域名。真机检查首页、分类筛选、分页、搜索、图片、代码段及转发，再提交审核。
5. 阅读接口无需登录，未开发微信身份登录，因此目前不需要 AppSecret。小程序仅显示已审核评论；提交留言请使用网站。原站外链复制到浏览器打开。

## H5

`npm run build:h5` 输出到 `uniapp/dist/build/h5`，可独立部署，也可作为公众号页面。网站本身也已适配手机屏幕。

官方参考：[Uni-app CLI](https://uniapp.dcloud.io/quickstart-cli)、[微信公众号接入](https://developers.weixin.qq.com/doc/offiaccount/Basic_Information/Access_Overview.html)。
