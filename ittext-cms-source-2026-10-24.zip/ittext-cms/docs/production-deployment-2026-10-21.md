# ittext.cn 生产部署与验收（2026-10-21）

## 菜单字体更新（2026-10-21 22:07）

已上传网站导航18px、手机展开菜单17px、后台侧栏16px及700字重的前端版本。此次仅更新 `web` 构建文件：本地与生产后端JAR SHA-256一致，无需替换；未重复导入数据或重启后端。

- 发布前完整前端备份：`/var/backups/ittext/frontend-before-menu-20261021-220753.tar.gz`，仅root可读。
- 保留旧哈希资源，先上传新资源再原子替换 `index.html`，Nginx配置检查通过。
- 外部HTTPS逐个验证9个发布文件的SHA-256与本地一致。
- 网站、后台入口、健康、分类、标签、广告、RSS、sitemap均返回200；grub搜索命中1篇；匿名后台访问401。
- 使用生产管理员验证登录、身份、统计及广告管理接口成功，Secure会话Cookie存在，测试结束退出登录。
- 浏览器确认正式站导航18px/700字重，无页面横向溢出、无损坏图片。截图：`screenshots/production-menu-2026-10-21.png`。
- 机器检查记录：`data/production-menu-verification.json`。本轮没有再次创建测试文章、评论或用户。

回退前先另存当前前端，将上述备份解压到独立目录核对，再恢复其资源与首页；后端和数据库无需回退。旧发布资源暂留以兼容已打开的页面。

## 部署结果

- 服务器：47.108.196.248，Rocky Linux 10.2。本次检查为全新系统，没有历史网站、宝塔或旧数据库可备份；使用本地 2026-10-20 迁移快照恢复内容。
- 原生软件：Java 21.0.12、MySQL 8.4.11、Nginx 1.26.3；未使用 Docker、容器或一键集成环境。
- 网站：https://ittext.cn；后台：https://ittext.cn/admin。HTTP 与 www 均 301 到正式域名。
- 独立数据库 ittext_cms，独立数据库与系统用户 ittext；后端 prod 配置，仅监听 127.0.0.1:18080，数据库仅监听回环地址。
- TLS：Let's Encrypt，2027-01-19 到期；systemd 每日续期检查。
- 生产管理员为 admin，随机新密码在 `data/production-admin-credentials.json`，与本地开发密码不同；该文件不提交源码，也不在聊天中展示。

## 发布目录与运维

- 发布：`/opt/ittext/releases/20261021`，当前软链 `/opt/ittext/current`。
- 数据：`/var/lib/ittext/uploads`；环境配置 `/etc/ittext/cms.env`（root 600）。
- 进程：`systemctl status ittext-cms nginx mysqld`；日志：`journalctl -u ittext-cms -n 100 --no-pager`。
- 重启：`systemctl restart ittext-cms`。已实际重启验证：健康检查正常，文章10条仍在。
- Nginx 配置：`/etc/nginx/conf.d/ittext.conf`；变更后先 `nginx -t` 再 reload。
- 每日03:20备份：`ittext-backup.timer`，保留14天，服务器时区 Asia/Shanghai。
- 手动备份：`/usr/local/sbin/ittext-backup`。备份目录 `/var/backups/ittext`，仅root访问，含数据库、附件及配置。
- 当前首份备份：`/var/backups/ittext/ittext-20261021-215300.tar.gz`。
- Nginx首次切换前配置保存于 `/var/backups/ittext/nginx-before-https`，该配置为新服务器默认配置，不是历史旧站。

## 验证证据

本地后端20项测试通过，前端生产构建成功。生产环境通过HTTPS连接真实MySQL验证：

- 10条内容：8篇公开文章、1个留言本、1篇草稿；7栏目、40标签、47附件，缺失0。
- 所有导入标题、发布时间、旧ID映射一致；草稿对匿名用户404。
- 47个附件HTTP字节的SHA-256与本地迁移文件一致，并带sandbox CSP。
- 搜索、栏目、标签、首页广告、后台入口、RSS、sitemap可访问。
- 管理员登录、Secure/HttpOnly Cookie、匿名后台拒绝及CSRF校验通过。
- 草稿创建→发布→详情→归档通过；评论提交→默认不可见→管理员审核→公开可见通过。
- PNG上传/读取及字节一致性通过；编辑可管理内容但不可访问账号管理。
- 重复导入新增0；本轮测试文章、评论、媒体、编辑账号均清理。
- 详细机器报告：`data/production-business-verification.json`。
- 业务验证脚本：服务器 `/root/ittext-business-verify.py`，通过 `/opt/certbot/bin/python` 执行。

注意：业务验证脚本按初次迁移内容总数断言，后续正式新增内容后不要直接当作日常健康检查反复运行。它会产生验证审计日志，日志保留。

## 恢复步骤

备份包含敏感配置，请仅由管理员操作，先保留当前备份再恢复。先停止 `ittext-cms`，把选定备份解压到独立临时目录；用 `mysql ittext_cms < database.sql` 恢复数据库，把附件恢复至 `/var/lib/ittext/uploads`，校正 ittext 用户属主后启动服务，验证健康检查、登录、文章及附件。不要直接覆盖 `/etc` 配置，先检查差异。

## 范围限制

微信公众号和微信小程序仍需用户提供正式 AppID/密钥及平台合法域名配置；本轮未进行微信平台授权、真机审核或发布，不能视为已完成微信端上线。

备份恢复演练：首份备份已恢复至独立临时 MySQL 数据库，10条文章、47条媒体记录一致，临时数据库已清理。浏览器实际登录生产后台成功，截图见 screenshots/production-admin-2026-10-21.png。

证书续期演练：certbot renew --dry-run 成功，ittext.cn 与 www.ittext.cn 全部通过。MySQL root 账户已设置独立随机密码，由 /root/.my.cnf（600）供本机管理员备份使用；应用仅使用独立 ittext 数据库账号。

