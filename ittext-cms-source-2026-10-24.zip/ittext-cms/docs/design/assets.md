# 第一稿素材记录

采用用户选定的第一张 Product Design 视觉稿：`docs/design/selected-editorial.png`。
全部新画面由内置 ImageGen 生成；没有使用外部 API CLI。品牌字标和 Lucide 图标沿用现有项目。

## 最终素材路径

| 网站素材 | 像素尺寸 | 字节 |
| --- | --- | --- |
| `web/public/design/cover-edge.webp` | 1942 × 809 | 322700 |
| `web/public/design/cover-grub.webp` | 1942 × 809 | 84144 |
| `web/public/design/cover-security.webp` | 1942 × 809 | 91872 |
| `web/public/design/cover-storage.webp` | 1942 × 809 | 83464 |
| `web/public/design/cover-windows.webp` | 1942 × 809 | 102966 |
| `web/public/design/hero-study.webp` | 2172 × 724 | 85322 |

小程序/H5 同名 JPEG 位于 `uniapp/src/static/design/`，6 张总计 354635 字节；网站 WebP 总计 770468 字节。
生成的 PNG 原件保留在本机 `.local/design-source/`，原始 ImageGen 文件也保留在 Codex generated_images 目录。格式编码脚本：`scripts/prepare-design-assets.py`。图片仅作格式/尺寸优化，没有将整页设计图当成页面背景。

## 提示词与约束

所有提示词均附上选定第一稿作为真实参考图。共同要求：与浅色森林绿 IT文档技术博客一致，真实编辑摄影风格，不含导航、按钮、广告或编号标注，文章封面独立生成。

- **hero-study**：1728×512 宽画幅；左45%干净暖白供真实DOM文字叠加，右55%阳光下的书桌、绿植、终端显示器、深绿 it. 杯子、Linux/Windows/Network/Tools书籍。终端内保留 whoami、cat philosophy.md 与知识记录文字；不生成页面标题或 CTA。实际输出2172×724，按容器等比裁切。
- **cover-storage**：960×400；右侧真实机械硬盘盘片，左侧深紫Ubuntu风格背景、Ubuntu字标与橙色标识，清晰的技术教程封面，无日期/按钮。
- **cover-edge**：960×400；深绿森林山景、左侧Rocky Linux绿色标识、右侧Edge蓝绿标识与简洁方向关系，无页面标题/按钮。
- **cover-windows**：960×400；Windows11蓝色折叠背景与右侧简化的可选功能面板，含“远程服务器管理工具 RSAT”和勾选项，不包含外层浏览器或广告。
- **cover-security**：960×400；Windows11蓝色背景与白色Windows Security面板、蓝色盾牌，无操作指令/按钮或广告。
- **cover-grub**：960×400；深蓝绿技术摄影，磁盘硬件与清晰暗色启动终端，简短“GRUB rescue”“grub>”文字，无标题/日期/外层UI。

## 使用规则

只有原站迁移封面或空封面采用对应默认新封面；管理员后续上传的自定义封面优先，不覆盖数据库和原始附件。
静态书桌图为本站介绍场景，不是轮播或广告。
