# 安全评估后续修复与复测

日期：2026-10-21。基于 `GB-T-39412-2020-audit.md` 的未关闭项进行修复。本记录更新上一轮结论，历史审计文件保留为基线。

## 修复结果

| 问题 | 处理 | 验证 |
| --- | --- | --- |
| 修改密码后，其他已登录会话仍能使用 | 登录登记会话；密码更新使该账号全部登记会话过期，当前会话立即注销。后台提示重新登录。过期会话下次请求返回401。 | 两个真实登录会话测试：修改前均可访问，修改后当前会话失效、第二会话401；旧密码拒绝，新密码可登录。 |
| HTTPS和跨域安全配置仅靠部署提醒 | 新增 `prod` profile 与启动校验：Secure Cookie、HTTPS公开地址、明确HTTPS跨域来源；拒绝通配符和带路径的Origin。生产会话超时30分钟。 | 无Secure、HTTP公开地址、通配来源、Origin含路径均被拒绝，合法配置通过。默认本地开发模式保留。 |
| Uni-app固定的旧依赖包含多个公告 | 保留DCloud5.26，采用明确版本的npm overrides更新Vue3.5.44、Vite6.4.5、Babel7.29.7、Express4.22.3、PostCSS8.5.31、ws8.22.0等；完整清单在 `uniapp/package.json` 及锁文件。没有使用 `--force`、`--legacy-peer-deps` 或降低审计等级。 | 干净 `npm ci`、完整 `npm ls --all`、H5/小程序构建通过。 |
| DCloud内嵌Vue3.4与Vue3.5共享工具的兼容差异 | Vue3.5的 `def()` 默认不可写，导致DCloud的slots更新抛错。为DCloud模块导入增加限定兼容层，保留旧版可写语义，其他调用继续使用补丁版共享工具。未回退安全补丁。 | 浏览器运行检查最初复现空白页及只读属性错误，修复后首页、文章跳转、富文本渲染通过，无页面脚本异常。 |
| braces递归栈耗尽（上游无修复版） | 本地MIT源码回补：解析栈深度上限128；compile/expand/stringify在递归前迭代验证AST深度、节点数量、循环引用。通过npm workspace解析，保留原版本3.0.3。 | 一万层嵌套字符串、直接传入的深AST/循环AST均受控拒绝，普通glob、范围展开正常；确认micromatch和chokidar实际解析到回补包。 |

## 原始告警与本地回补的区别

干净安装后的官方npm审计：从上一轮49个包级告警降为 **18个高危包级告警**，0中危、0低危、0严重。这18项全部来自同一个具体公告 [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm)，其余是向DCloud、chokidar、micromatch等包传播的依赖告警。

braces保留上游版本号，因此npm只按版本匹配仍报警；实际执行代码已经回补，原始告警没有被关闭或隐藏。此前临时路径覆盖曾使扫描返回0，但干净安装暴露其路径解析错误，已弃用；最终采用workspace，并以当前18条原始结果为准。**不能把当前结果写成npm审计0告警。**

源码、MIT许可与回补维护说明在 `uniapp/vendor/braces/`。`scripts/verify-uniapp-security.cjs` 会检查原始报告的全部公告来源，只允许这一个已回补公告及其传播，并运行实际补丁和解析路径回归；任何其他公告均会使验证失败。它是补丁证据核验，不是绕过npm审计或完整SCA工具。未来出现上游修复版后，应替换本地回补并再次复测。

## 最终验证

- 后端：20项测试，0失败、0错误、0跳过，JAR打包成功。
- 网站：生产构建成功，包含改密后的退出流程。
- Uni-app：锁文件干净安装成功，完整依赖树无无效/缺失项；安全回归通过；H5、微信小程序生产构建成功。
- H5运行检查：在临时本地只读接口样例上验证首页、文章跳转和富文本，无页面脚本异常；不是生产后端联调。未进行微信真机验证，Appid仍需实际配置。
- 复测证据位于 `followup-*` 文件及 `npm-uniapp-remediated.json`；保留上一轮before/after报告作比较。

复现命令（在项目根目录，工具已安装的环境）：

```text
mvn -f backend/pom.xml verify
npm --prefix web run build
cd uniapp
npm ci
npm run test:security
npm run build:h5
npm run build:mp-weixin
npm ls --all
npm audit --json > ../docs/security/npm-uniapp-remediated.json
cd ..
node scripts/verify-uniapp-security.cjs
```

原生npm audit仍会因上游版本告警返回非零，需结合本地回补证据判断，不能丢弃其输出。

## 生效与边界

源码、锁文件和构建产物均在本地，尚未部署或重启原有服务。生产使用 `SPRING_PROFILES_ACTIVE=prod`，同时提供 `PUBLIC_URL=https://实际域名`、`ALLOWED_ORIGIN=https://实际域名`。仍需按部署文档配置TLS和附件安全头转发。

会话登记与登录限速当前属于单实例内存机制。生产若改为多实例，必须使用共享会话/撤销和共享限流方案；本次没有新增Redis等基础设施。初始密码文件权限、审计日志留存告警、可信反向代理和微信消息加密模式仍是部署/集成事项，不能据本次代码修复认定生产环境已验证或标准97项全部达标。DCloud/Vue兼容层与本地回补需要随将来的工具链升级维护。

参考：[DCloud CLI版本管理说明](https://uniapp.dcloud.net.cn/quickstart-cli.html)、上述漏洞公告；版本和最终计数以保存的npm原始报告、锁文件及复测证据为准。
