import { createApp } from 'vue'
import {createRouter,createWebHistory} from 'vue-router'
import App from './App.vue'
import Blog from './Blog.vue'
import Admin from './Admin.vue'
import './style.css'
import './editorial.css'
import {legacyCategoryRedirect} from './category-route'
const router=createRouter({history:createWebHistory(),routes:[{path:'/admin/:section?',component:Admin},{path:'/category/:categoryId([1-9]\\d*)',component:Blog},{path:'/:pathMatch(.*)*',component:Blog}]})
router.beforeEach(to=>legacyCategoryRedirect(to))
createApp(App).use(router).mount('#app')
