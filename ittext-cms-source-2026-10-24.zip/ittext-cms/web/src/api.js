let token=''
export async function csrf(){const r=await fetch('/api/auth/csrf',{credentials:'include'});if(!r.ok)throw new Error('无法获取安全令牌');token=(await r.json()).token}
export async function api(path,options={}){
  const method=options.method||'GET'
  if(method!=='GET'&&!token)await csrf()
  const headers={...options.headers}
  if(options.body&&!(options.body instanceof FormData)){headers['Content-Type']='application/json';options.body=JSON.stringify(options.body)}
  if(method!=='GET')headers['X-CSRF-TOKEN']=token
  const r=await fetch('/api'+path,{...options,headers,credentials:'include'})
  if(!r.ok){const data=await r.json().catch(()=>({}));const error=new Error(data.message||({401:'请先登录',403:'权限不足或登录已过期，请重新登录',409:'数据冲突'}[r.status])||'请求失败');error.status=r.status;throw error}
  return r.status===204||r.headers.get('content-length')==='0'?null:await r.text().then(t=>t?JSON.parse(t):null)
}
export const date=n=>new Date(Number(n)).toLocaleDateString('zh-CN',{year:'numeric',month:'2-digit',day:'2-digit'})
export const number=n=>Number(n||0).toLocaleString('zh-CN')
