export function categoryLocation(input={}) {
  const query={...input},category=String(query.category||'')
  delete query.category
  return {path:/^[1-9]\d*$/.test(category)?`/category/${category}`:'/',query}
}
export function legacyCategoryRedirect(to) {
  if(to.path==='/'&&/^[1-9]\d*$/.test(String(to.query.category||''))&&!to.query.id)
    return {...categoryLocation(to.query),hash:to.hash,replace:true}
}
