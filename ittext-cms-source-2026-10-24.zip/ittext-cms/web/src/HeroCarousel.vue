<script setup>
import {ref,onMounted,onUnmounted,computed} from 'vue'
import {api} from './api'
const slides=ref([]),index=ref(0),paused=ref(false),manualPause=ref(false)
const current=computed(()=>slides.value[index.value])
let timer
function move(step){index.value=(index.value+step+slides.value.length)%slides.value.length}
onMounted(async()=>{try{slides.value=await api('/slides')}catch{};timer=setInterval(()=>{if(slides.value.length>1&&!paused.value&&!manualPause.value&&!document.hidden&&!matchMedia('(prefers-reduced-motion: reduce)').matches)move(1)},6000)})
onUnmounted(()=>clearInterval(timer))
</script>
<template>
 <section v-if="current" class="hero ad-carousel" aria-label="首页广告" aria-roledescription="轮播图" @mouseenter="paused=true" @mouseleave="paused=false" @focusin="paused=true" @focusout="paused=false">
  <a :href="current.link" class="slide-link" :aria-label="current.title" :key="index">
   <img class="hero-background" :src="current.image" :alt="current.title" fetchpriority="high">
   <div class="hero-inner site-container"><div class="hero-copy"><div class="eyebrow">精选推荐 · {{index+1}} / {{slides.length}}</div><h1>{{current.title}}</h1><p>{{current.description}}</p><span class="button primary">{{current.button||'查看详情'}} <span aria-hidden="true">→</span></span></div></div>
  </a>
  <div v-if="slides.length>1" class="slide-controls" aria-label="广告切换"><button @click="move(-1)" aria-label="上一张广告">‹</button><button v-for="(slide,i) in slides" :key="i" class="slide-dot" :class="{active:i===index}" :aria-label="'第'+(i+1)+'张：'+slide.title" :aria-pressed="i===index" @click="index=i"></button><button @click="move(1)" aria-label="下一张广告">›</button><button @click="manualPause=!manualPause" :aria-label="manualPause?'自动播放广告':'暂停广告'">{{manualPause?'播放':'暂停'}}</button></div>
 </section>
</template>
<style>
.ad-carousel{position:relative}.ad-carousel .slide-link{display:block;height:100%;color:inherit;text-decoration:none}.ad-carousel .hero-copy h1{max-width:100%;white-space:pre-line;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden}.ad-carousel .hero-copy .button{margin-top:18px}.ad-carousel .hero-copy p{white-space:pre-line;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden}.slide-controls{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:12px;padding:6px 12px;border-radius:24px;background:#fffdebea;z-index:3}.slide-controls button{border:0;background:transparent;color:#176b57;cursor:pointer;font-size:16px}.slide-controls .slide-dot{width:9px;height:9px;padding:0;border-radius:50%;background:#aabdb6}.slide-controls .slide-dot.active{background:#176b57;width:24px;border-radius:6px}.ad-carousel:focus-within{outline:2px solid #176b57;outline-offset:-2px}@media(max-width:600px){.ad-carousel .slide-link{display:flex;flex-direction:column}.ad-carousel .hero-background{order:2}.ad-carousel .hero-inner{order:1}.ad-carousel .hero-copy h1{font-size:32px}.ad-carousel .slide-controls{bottom:10px;max-width:95%;gap:9px}}
</style>
