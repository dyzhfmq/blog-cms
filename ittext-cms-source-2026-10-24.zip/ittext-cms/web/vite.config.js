import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({plugins:[vue()],server:{port:5173,strictPort:true,proxy:{'/api':'http://127.0.0.1:8080','/uploads':'http://127.0.0.1:8080','/sitemap.xml':'http://127.0.0.1:8080','/feed.xml':'http://127.0.0.1:8080'}}})
