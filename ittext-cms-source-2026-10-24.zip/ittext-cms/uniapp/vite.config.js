import {defineConfig} from 'vite'
import uni from '@dcloudio/vite-plugin-uni'
import {fileURLToPath} from 'node:url'
const dcloudSharedCompatibility={name:'dcloud-vue34-shared-compat',enforce:'pre',resolveId(source,importer){
 if(source==='@vue/shared'&&importer?.replaceAll('\\','/').includes('/node_modules/@dcloudio/'))
  return fileURLToPath(new URL('./build/vue-shared-compat.mjs',import.meta.url))
}}
export default defineConfig({plugins:[dcloudSharedCompatibility,uni.default?uni.default():uni()],server:{host:'127.0.0.1',port:5174,strictPort:true,proxy:{'/api':'http://127.0.0.1:8080','/uploads':'http://127.0.0.1:8080'}}})
