<script setup>
import {ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import {request} from '../../utils/api'
const items=ref([]),error=ref('')
async function load(){error.value='';try{items.value=await request('/categories')}catch(e){error.value=e.message}}
function open(id){uni.setStorageSync('selectedCategory',id);uni.switchTab({url:'/pages/index/index'})}
onLoad(load)
</script>
<template><view class="page"><view class="eyebrow">EXPLORE THE KNOWLEDGE</view><view class="section-title">按兴趣，慢慢探索。</view><view class="sub">整理经验，让知识井然有序。</view><view class="category-grid"><view v-for="(c,i) in items" :key="c.id" class="category-card" @tap="open(c.id)"><view class="category-number">0{{i+1}} /</view><view class="category-title">{{c.name}}</view><view class="sub">{{c.article_count}} 篇笔记 <text>↗</text></view></view></view><view v-if="error" class="state error">{{error}}<button class="empty-btn" @tap="load">重试</button></view></view></template>
<style scoped>.category-grid{display:grid;grid-template-columns:1fr 1fr;gap:22rpx;margin-top:40rpx}.category-card{padding:30rpx;background:white;border:1rpx solid #e0e8d7;border-radius:18rpx}.category-number{font-family:monospace;color:#a5b39b;font-size:24rpx}.category-title{font-size:32rpx;font-weight:600;margin-top:30rpx}.category-card .sub{display:flex;justify-content:space-between}</style>
