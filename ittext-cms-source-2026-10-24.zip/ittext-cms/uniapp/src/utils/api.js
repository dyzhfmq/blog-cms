export const BASE=import.meta.env.VITE_API_BASE||''
export function request(path){return new Promise((resolve,reject)=>{uni.request({url:BASE+'/api'+path,success:r=>r.statusCode===200?resolve(r.data):reject(new Error(r.data?.message||'加载失败，请稍后重试')),fail:()=>reject(new Error('网络连接失败，请检查网络或接口域名配置'))})})}
export const media=url=>url?.startsWith('/')?BASE+url:url
export const date=n=>new Date(Number(n)).toLocaleDateString()
